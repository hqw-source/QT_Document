#include "widget.h"
#include "ui_widget.h"
#include "setdata.h"
#include "dataanalyse.h"
#include "Dask64.h"
#include <QChart>
#include <QtCharts>
#include <QGraphicsWidget>
#include <conio.h>
#define DataSize  2048
QChart *chart0;
QValueAxis *axsisX0;
QValueAxis *axsisY0;
QLineSeries *seriesQ;
QLineSeries *seriesP1;
QLineSeries *seriesP2;
QLineSeries *seriesW;
QLineSeries *seriesT;
QLineSeries *seriesL;
QLineSeries *seriesN;
QLineSeries *seriesKV;
QChartView *cview0;
//采样时间值
int timeCount_ms=0;
int timeCount_s=0;
int cardifo=PCI_9111DG;//HR
int count=0;
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    //设置数据分析和参数设置信号与槽
    m_b = new setData(this);
    m_c = new dataAnalyse(this);
    connect(m_b,SIGNAL(openWidgetSignal()),this,SLOT(showWidget()));
    connect(m_c,QOverload<>::of(&dataAnalyse::openWidgetSignal),this,QOverload<>::of(&Widget::showWidget));

//    int Err=0,card=0;
//    U32  MemSize = 0, Db_buf[2];
//    unsigned long i[10];
//    ULONG_PTR viewAddr;
//    U32 read_count = DataSize, count = 0;
//    F64 data[100000];

    //注册采集卡
    //返回初始化的卡的数字卡ID。卡ID取值范围为0 ~ 31。如果发生任何错误，则返回负错误代码。
    //Register_Card(U16 CardType, U16 card_num);
//    card=Register_Card(cardifo,0);
//    if((Err=card)<0){
//        qDebug()<<"Register_Card error=="<<Err;
//        exit(1);
//    }
//    else
//    {
//        qDebug()<<"Register_Card ok=="<<card;
//    }
    //返回系统启动时在驱动程序中为连续操作分配的内存的映射缓冲区地址。
    //分配的内存大小可以通过函数Al_InitialMemoryAllocated获得。
    //此功能不适用于单缓冲连续模拟输入操作的中(约)触发或预触发模式。
    //here to get the starting addresses of two driver DB buffers
        //    Err=AI_GetView(card,&viewAddr); //viewAddr : driver buffer
        //    if(Err<0){
        //     qDebug()<<"AI_GetView error=="<<Err;
        //     exit(1);
        //     }
        //    else
        //    {
        //        qDebug()<<"AI_GetView ok=="<<Err;
        //    }

        //     Err= AI_InitialMemoryAllocated(card, &MemSize);
        //     if(Err<0){
        //     qDebug()<<"AI_InitialMemoryAllocated error=="<<Err;
        //     exit(1);
        //     }
        //    else
        //    {
        //        qDebug()<<"AI_InitialMemoryAllocated ok=="<<Err;
        //    }
        //     Db_buf[0] = viewAddr; //1st DB buffer address
        //     Db_buf[1] = viewAddr + (MemSize * 1024 / 2); //2nd DB buffer address

     //AI_9111_Config(CardNumber执行操作的卡ID,TrigSoure连续AD转换触发源,Tirg触发模式选择,TraceCnt)
//     Err=AI_9111_Config(card, TRIG_INT_PACER, P9111_TRGMOD_SOFT, 0);
//     if(Err<0){
//     qDebug()<<"AI_9111_Config error=="<<Err;
//     exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_9111_Config ok=="<<Err;
//     }

    //AI_AsyncDblBufferMode(U16 CardNumber, BOOLEAN Enable);
    //启用或禁用双缓冲数据采集模式
//     Err = AI_AsyncDblBufferMode(card, TRUE);
//     if(Err<0){
//     qDebug()<<"AI_InitialMemoryAllocated error=="<<Err;
//     exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_InitialMemoryAllocated ok=="<<Err;
//     }
     //在执行连续A/D转换时，调用此函数以获取A/D状态。
     //I16 AI_ContStatus (U16 CardNumber, U16 *Status)
     //*Status 返回的连续Al状态。列出了各种卡类型的Status参数说明。
     //PCI-9111 bit 0=FIFO为空 1-半满 2-已满数据可能丢失 3-AD忙;A/D数据没有锁存到FIFO中 4~15未使用
//     U16 *ContStatus = nullptr;
//     Err=AI_ContStatus(card,ContStatus);
//     if(Err<0){
//       qDebug()<<"AI_ContStatus error=="<<Err;
//       exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_ContStatus ok=="<<Err;
//     }
    //
    //AI_ContReadChannel(U16 CardNumber, U16 Channel, U16 AdRange, U16 *Buffer, U32 ReadCount, F64 SampleRate, U16 SyncMode);
    //Channel(0 to 15)
    //AdRange：AD_B_10_V, AD_B_5_V, AD_B_2_5_V, AD_B_1_25_V,AD_B_0_625_V  B双极 U单极
    //*Buffer:如果启用了双缓冲模式，这个缓冲区无效
    //ReadCount读取样本通道的数量必须是4的倍数
    //SampleRate采样率
    //SyncMode采样模式 同步或异步
//     Err=AI_ContReadChannel(card,0,AD_B_10_V,NULL,400,2048,ASYNCH_OP);//
//     if(Err<0){
//       qDebug()<<"AI_ContReadChannel error=="<<Err;
//       exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_ContReadChannel ok=="<<Err;
//     }
     //读选中通道的电压数据值
     //在模拟输入通道上执行软件触发的a /D转换(模拟输入)，并将缩放后的值以伏特为单位返回电压。
     //AI_VReadChannel (U16 CardNumber, U16 Channel,U16 AdRange, F64 *voltage)
     //Channel(0 to 15)
     //AdRange:AD_B_10_V, AD_B_5_V, AD_B_2_5_V, AD_B_1_25_V,AD_B_0_625_V  B双极 U单极
     //*voltage返回测量的电压值并按比例缩放为电压单位。
//     F64 *voltage=nullptr;
//     Err=AI_VReadChannel(card,0,AD_B_10_V,voltage);
//     if(Err<0){
//       qDebug()<<"AI_VReadChannel error=="<<Err;
//       exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_VReadChannel ok=="<<Err;
//     }
    //停止异步模拟输入操作。
    //AI_AsyncClear(CardNumber,AccessCnt)
    //在不使用触发器采集模式的情况下，AccessCnt返回callingAl_AsyncClear()时已经传输的A/D数据数。
    //如果启用双缓冲模式，AccessCnt返回最后一个A/D数据在循环缓冲区中存储的位置之后的下一个位置。
    //如果accessnt超过了循环缓冲区的一半大小，调用两次Al_AsyncDblBufferTransfer来获取数据。
//    Err=AI_AsyncClear(card, &count);
//    if(Err<0){
//        qDebug()<<"AI_AsyncClear error=="<<Err;
//        exit(1);
//    }
//     else
//     {
//       qDebug()<<"AI_AsyncClear ok=="<<Err;
//     }
    //释放注册的采集卡
//     Err=Release_Card(card);
//     if(Err<0){
//     qDebug()<<"Release_Card error=="<<Err;
//     exit(1);
//     }
//     else
//     {
//       qDebug()<<"Release_Card ok=="<<Err;
//     }
    /********************软件界面*************************/
    setWindowTitle("当前状态:凌华PCI9111数据采集卡采集软件");
    //设置窗口大小
    setFixedSize(1900,900);
    /******************软件参数初始化*********************/
    //默认文件名
    ui->fileNameText->setText("labtest01.text");
    // 曲线颜色提示
    // 获取当前控件的调色板（palette）
    QPalette palette = ui->P1labelColor->palette();
    // 将调色板的背景角色（background role）设置为红色
    palette.setColor(QPalette::Window, Qt::red);
    // 应用新的调色板到控件上
    // 压力P1
    ui->P1labelColor->setAutoFillBackground(true);
    ui->P1labelColor->setPalette(palette);
    // 压力P2
    palette.setColor(QPalette::Window, Qt::blue);
    ui->P2labelColor->setAutoFillBackground(true);
    ui->P2labelColor->setPalette(palette);
    // 流量Q
    palette.setColor(QPalette::Window, Qt::black);
    ui->QlabelColor->setAutoFillBackground(true);
    ui->QlabelColor->setPalette(palette);
    // 功率W
    palette.setColor(QPalette::Window, Qt::green);
    ui->WlabelColor->setAutoFillBackground(true);
    ui->WlabelColor->setPalette(palette);
    // 油温T
    palette.setColor(QPalette::Window, Qt::yellow);
    ui->TlabelColor->setAutoFillBackground(true);
    ui->TlabelColor->setPalette(palette);
    // 位移L
    palette.setColor(QPalette::Window, QColor(255,100,0));//橙色
    ui->LlabelColor->setAutoFillBackground(true);
    ui->LlabelColor->setPalette(palette);
    // 转速N
    palette.setColor(QPalette::Window, QColor(0,255,255));//天蓝
    ui->NlabelColor->setAutoFillBackground(true);
    ui->NlabelColor->setPalette(palette);
    // 控制KV
    palette.setColor(QPalette::Window, QColor(255,0,255));//洋红
    ui->KVlabelColor->setAutoFillBackground(true);
    ui->KVlabelColor->setPalette(palette);
    /********************图表界面************************/
    /***********采集通道0的曲线图显示界面*************/
    cview0=new QChartView(this);
    chart0 = new QChart();
    chart0->setTitle("采集曲线图");
    cview0->setChart(chart0);
    cview0->setRenderHint(QPainter::Antialiasing);
    cview0->resize(1510,840);
    axsisX0=new QValueAxis();
    axsisY0=new QValueAxis();
    axsisX0->setTitleText("时间/ms");
    axsisX0->setRange(0,ui->xAxisMaxSlider->value());
    axsisY0->setRange(ui->yAxisMinSpinBox->value(), ui->yAxisMaxSpinBox->value());
    axsisY0->setTitleText("电压/V");
    axsisX0->setTickCount(9);
    axsisY0->setTickCount(9);
    //添加流量Q曲线到图表中
    seriesQ=new QLineSeries();
    seriesQ->setName("流量Q");
    chart0->addSeries(seriesQ);
    chart0->addAxis(axsisX0,Qt::AlignBottom);
    chart0->addAxis(axsisY0,Qt::AlignLeft);
    seriesQ->attachAxis(axsisX0);
    seriesQ->attachAxis(axsisY0);
    seriesQ->setColor(Qt::black);
    //添加压力P1曲线到图表中
    seriesP1=new QLineSeries();
    seriesP1->setName("压力P1");
    chart0->addSeries(seriesP1);
    seriesP1->attachAxis(axsisX0);
    seriesP1->attachAxis(axsisY0);
    seriesP1->setColor(Qt::red);
    //添加压力P2曲线到图表中
    seriesP2=new QLineSeries();
    seriesP2->setName("压力P2");
    chart0->addSeries(seriesP2);
    seriesP2->attachAxis(axsisX0);
    seriesP2->attachAxis(axsisY0);
    seriesP2->setColor(Qt::blue);
    //添加功率W曲线到图表中
    seriesW=new QLineSeries();
    seriesW->setName("功率W");
    chart0->addSeries(seriesW);
    seriesW->attachAxis(axsisX0);
    seriesW->attachAxis(axsisY0);
    seriesW->setColor(Qt::green);
    //添加油温T曲线到图表中
    seriesT=new QLineSeries();
    seriesT->setName("油温T");
    chart0->addSeries(seriesT);
    seriesT->attachAxis(axsisX0);
    seriesT->attachAxis(axsisY0);
    seriesT->setColor(Qt::yellow);
    //添加位移L曲线到图表中
    seriesL=new QLineSeries();
    seriesL->setName("位移L");
    chart0->addSeries(seriesL);
    seriesL->attachAxis(axsisX0);
    seriesL->attachAxis(axsisY0);
    seriesL->setColor(QColor(255,100,0));
    //添加位转速N曲线到图表中
    seriesN=new QLineSeries();
    seriesN->setName("转速N");
    chart0->addSeries(seriesN);
    seriesN->attachAxis(axsisX0);
    seriesN->attachAxis(axsisY0);
    seriesN->setColor(QColor(0,255,255));
    //添加位控制kv曲线到图表中
    seriesKV=new QLineSeries();
    seriesKV->setName("控制kv");
    chart0->addSeries(seriesKV);
    seriesKV->attachAxis(axsisX0);
    seriesKV->attachAxis(axsisY0);
    seriesKV->setColor(QColor(255,0,255));
    /**************功能控制区显示*************/
    /**********开始保存采样数据时间显示*********/
    connect(timer1,&QTimer::timeout,this,[=](){
        timeCount_ms++;
        if(timeCount_ms==1000) {
        timeCount_ms=0;
        timeCount_s++;
        }
        ui->samplingTimeLCD_ms->display(timeCount_ms);
        ui->samplingTimeLCD_s->display(timeCount_s);
        //通过定时器的曲线显示
        int a=rand()%10;
        int b=rand()%10;
        int c=rand()%10;
        if(timeCount_ms%10==2)
        {
        seriesQ->append(count++,a);
        seriesP1->append(count,b+10);
        seriesP2->append(count,c*3);
        }

        ui->LCD_Q->display(a);
        ui->LCD_P1->display(b+10);
        ui->LCD_P2->display(c*3);

    });


/*************test程序代码*****************/

}
Widget::~Widget()
{
    delete ui;
}
void Widget::showWidget()
{
    m_b->hide();
    m_c->hide();
    this->show();
}
//打开参数设定窗口
void Widget::on_setParBtn_clicked()
{
    this->hide();
    m_b->show();
}
//打开数据分析窗口
void Widget::on_dataAnlBtn_clicked()
{
    this->hide();
    m_c->show();
}
//数据清除
void Widget::on_dataClearBtn_clicked()
{
    seriesQ->clear();
    seriesP1->clear();
    seriesP2->clear();
    count=0;
    timer1->stop();
    ui->samplingTimeLCD_ms->display(0);
    ui->samplingTimeLCD_s->display(0);
}
//打开文件路径
void Widget::on_filePathBtn_clicked()
{
        //    auto filename=QFileDialog::getExistingDirectory(this,"选择文件路径",
        //                            QStandardPaths::writableLocation(QStandardPaths::DesktopLocation));
        //    QString filename1=filename;
        //    filename1.append("/");
        //    filename1.append(ui->fileNameText->toPlainText());
        //    ui->filePathText->setPlainText(filename1);
        //    // 创建并打开要写入的txt文件
        //    QString filePath = filename1;
        //    QFile file(filePath);
        //    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        //        qDebug() << "无法打开文件" << filePath;
        //    }
        //    // 获取文本流对象
        //    QTextStream out(&file);
        //    // 向文本流中写入数据
        //    out << "Hello World!" << endl;
        //    out << "This is some data." << endl;
        //    // 关闭文件
        //    file.close();
}
//图表X、Y轴范围设置
void Widget::on_xAxisMaxSpinBox_valueChanged(int)
{
    axsisX0->setRange(ui->xAxisMinSpinBox->value(), ui->xAxisMaxSpinBox->value());
    if(ui->xAxisMaxSpinBox->value()<ui->xAxisMinSpinBox->value())
    {
        ui->xAxisMaxSlider->setValue(ui->xAxisMinSpinBox->value());
        ui->xAxisMaxSlider->setValue(ui->xAxisMiniSlider->value());
    }
}
void Widget::on_xAxisMinSpinBox_valueChanged(int)
{
    axsisX0->setRange(ui->xAxisMinSpinBox->value(), ui->xAxisMaxSpinBox->value());
    if(ui->xAxisMinSpinBox->value()>ui->xAxisMaxSpinBox->value())
    {
        ui->xAxisMinSpinBox->setValue(ui->xAxisMaxSlider->value());
        ui->xAxisMiniSlider->setValue(ui->xAxisMaxSlider->value());
    }
}
void Widget::on_yAxisMaxSpinBox_valueChanged(int)
{
    axsisY0->setRange(ui->yAxisMinSpinBox->value(), ui->yAxisMaxSpinBox->value());
}
void Widget::on_yAxisMinSpinBox_valueChanged(int)
{
    axsisY0->setRange(ui->yAxisMinSpinBox->value(), ui->yAxisMaxSpinBox->value());
}
//开始采样
void Widget::on_startSamplingBtn_clicked()
{
    //启动定时器
    timer1->start(1);
    //定时器清零
    timeCount_ms=0;
    timeCount_s=0;
    //
}
//停止采样
void Widget::on_stopSamplingBtn_clicked()
{
    //停止定时器
    timer1->stop();
}
//流量Q曲线显示/隐藏
void Widget::on_Q_CheckBox_stateChanged(int )
{
    if(bool(ui->Q_CheckBox->checkState())==0)
    seriesQ->hide();
    if(bool(ui->Q_CheckBox->checkState())==1)
    seriesQ->show();
}
//压力P1曲线显示/隐藏
void Widget::on_P1_CheckBox_stateChanged(int )
{
    if(bool(ui->P1_CheckBox->checkState())==0)
    seriesP1->hide();
    if(bool(ui->P1_CheckBox->checkState())==1)
    seriesP1->show();
}
//压力P2曲线显示/隐藏
void Widget::on_P2_CheckBox_stateChanged(int )
{
    if(bool(ui->P2_CheckBox->checkState())==0)
    seriesP2->hide();
    if(bool(ui->P2_CheckBox->checkState())==1)
    seriesP2->show();
}
//功率W曲线显示/隐藏
void Widget::on_W_CheckBox_stateChanged(int )
{
    if(bool(ui->W_CheckBox->checkState())==0)
    seriesW->hide();
    if(bool(ui->W_CheckBox->checkState())==1)
    seriesW->show();
}
//油温T曲线显示/隐藏
void Widget::on_T_CheckBox_stateChanged(int )
{
    if(bool(ui->T_CheckBox->checkState())==0)
    seriesT->hide();
    if(bool(ui->T_CheckBox->checkState())==1)
    seriesT->show();
}
//位移L曲线显示/隐藏
void Widget::on_L_CheckBox_stateChanged(int )
{
    if(bool(ui->L_CheckBox->checkState())==0)
    seriesL->hide();
    if(bool(ui->L_CheckBox->checkState())==1)
    seriesL->show();
}
//转速N曲线显示/隐藏
void Widget::on_N_CheckBox_stateChanged(int )
{
    if(bool(ui->N_CheckBox->checkState())==0)
    seriesN->hide();
    if(bool(ui->N_CheckBox->checkState())==1)
    seriesN->show();
}
//控制kv曲线显示/隐藏
void Widget::on_kv_CheckBox_stateChanged(int )
{
    if(bool(ui->kv_CheckBox->checkState())==0)
    seriesKV->hide();
    if(bool(ui->kv_CheckBox->checkState())==1)
    seriesKV->show();
}



