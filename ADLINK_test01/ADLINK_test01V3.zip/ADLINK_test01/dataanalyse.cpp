#include "dataanalyse.h"
#include "ui_dataanalyse.h"
#include <QFileDialog>
#include <QDebug>
#include <QAxObject>
#include <QDir>
#include <QFile>
#include <QDateTime>
#include <QTableWidget>
#include <QString>
#include <QWidget>
dataAnalyse::dataAnalyse(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::dataAnalyse)
{
    ui->setupUi(this);
    /********************软件界面*************************/
    setWindowTitle("当前状态:凌华PCI9111数据采集卡采集软件->数据分析");
    //设置窗口大小
    setFixedSize(1600,900);
    //表格数据
    QTableWidgetItem  *Exceldata_Q = new QTableWidgetItem;
    QTableWidgetItem  *Exceldata_P1 = new QTableWidgetItem;
    QTableWidgetItem  *Exceldata_P2 = new QTableWidgetItem;
    QTableWidgetItem  *Exceldata_W = new QTableWidgetItem;
    QTableWidgetItem  *Exceldata_T = new QTableWidgetItem;
    QTableWidgetItem  *Exceldata_N = new QTableWidgetItem;
    QTableWidgetItem  *Exceldata_KV = new QTableWidgetItem;
    QTableWidgetItem  *Exceldata_S = new QTableWidgetItem;
    float q=rand();
    float P1=rand();
    float P2=rand();
    float W=rand();
    float T=rand();
    float N=rand();
    float KV=rand();
    float Time=rand();
    QString data_Q=QString::number(q);
    QString data_P1=QString::number(P1);
    QString data_P2=QString::number(P2);
    QString data_W=QString::number(W);
    QString data_T=QString::number(T);
    QString data_N=QString::number(N);
    QString data_KV=QString::number(KV);
    QString data_Time=QString::number(Time);
    Exceldata_Q->setText(data_Q);
    ui->tableWidget->setItem(0,0,Exceldata_Q);
    Exceldata_P1->setText(data_P1);
    ui->tableWidget->setItem(0,1,Exceldata_P1);
    Exceldata_P2->setText(data_P2);
    ui->tableWidget->setItem(0,2,Exceldata_P2);
    Exceldata_W->setText(data_W);
    ui->tableWidget->setItem(0,3,Exceldata_W);
    Exceldata_T->setText(data_T);
    ui->tableWidget->setItem(0,4,Exceldata_T);
    Exceldata_N->setText(data_N);
    ui->tableWidget->setItem(0,5,Exceldata_N);
    Exceldata_KV->setText(data_KV);
    ui->tableWidget->setItem(0,6,Exceldata_KV);
    Exceldata_S->setText(data_Time);
    ui->tableWidget->setItem(0,7,Exceldata_S);
}
dataAnalyse::~dataAnalyse()
{
    delete ui;
}
//返回Widget窗口
void dataAnalyse::on_backWidgetBtn_clicked()
{
    this->hide();
    emit openWidgetSignal();
}
//保存数据按钮
void dataAnalyse::on_readDataBtn_clicked()
{
QString fileName = QFileDialog::getSaveFileName(this,
        tr("Excle 保存路径"),QString("./test.xlsx"),tr("Excel Files(*.xlsx)"));    //设置保存的文件名
    if(fileName != NULL)
    {
        QAxObject *excel = new QAxObject;
        if(excel->setControl("Excel.Application"))
        {
            excel->dynamicCall("SetVisible (bool Visible)",false);
            excel->setProperty("DisplayAlerts",false);
            QAxObject *workbooks = excel->querySubObject("WorkBooks");
            workbooks->dynamicCall("Add");
            QAxObject *workbook = excel->querySubObject("ActiveWorkBook");
            QAxObject *worksheet = workbook->querySubObject("Worksheets(int)", 1);
            QAxObject *cell;
            int rowCount = ui->tableWidget->rowCount();
            int columnCount = ui->tableWidget->columnCount();
            qDebug()<<"columnCount"<<columnCount<<"rowCount"<<rowCount;
            //保存水平和垂直方向上的表格头
            for(int i=1;i <= columnCount ; i++)
            {
                cell = worksheet->querySubObject("Cells(int,int)", 1, i+1);
                cell->dynamicCall("SetValue(const QString&)", ui->tableWidget->horizontalHeaderItem(i-1)->data(0).toString());

            }
            for(int j=1;j <= rowCount ; j++)
            {
                cell = worksheet->querySubObject("Cells(int,int)", j+1, 1);
                cell->dynamicCall("SetValue(const QString&)", ui->tableWidget->verticalHeaderItem(j-1)->data(0).toString());
            }
            //无数据或缺少数据会崩溃
            for(int i=1;i <= rowCount ; i++)
            {
                for(int j=1;j <= columnCount ; j++)
                {
                    cell = worksheet->querySubObject("Cells(int,int)", i+1, j+1);
                    cell->dynamicCall("SetValue(const QString&)", ui->tableWidget->item(i-1,j-1)->data(0).toString());
                }
            }
            workbook->dynamicCall("SaveAs(const QString&)",QDir::toNativeSeparators(fileName));
            workbook->dynamicCall("Close()");
            excel->dynamicCall("Quit()");
            delete excel;
            excel = NULL;
        }
    }
}

