#include "setdata.h"
#include "ui_setdata.h"
#include "widget.h"
setData::setData(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::setData)
{
    ui->setupUi(this);
    /********************软件界面*************************/
    setWindowTitle("参数设定");
    //设置窗口大小
    setFixedSize(1000,900);
}
setData::~setData()
{
    delete ui;
}
//返回Widget采集界面
void setData::on_backBtn_clicked()
{
    this->hide();
    Widget *w=new Widget();
    w->show();
}

