#include "widget.h"
#include "ui_widget.h"
#include "setdata.h"
#include "Dask64.h"
#include <QChart>
#include <QtCharts>
#include <QGraphicsWidget>
#include <conio.h>
#define DataSize  2048
QChart *chart0;
QValueAxis *axsisX0;
QValueAxis *axsisY0;
QLineSeries *series0;
QChartView *cview0;

QChart *chart1;
QValueAxis *axsisX1;
QValueAxis *axsisY1;
QLineSeries *series1;
QChartView *cview1;

int cardifo=PCI_9111DG;
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    int Err=0,card=0;
    U32  MemSize = 0, Db_buf[2];
    unsigned long i[10];
    ULONG_PTR viewAddr;
    U32 read_count = DataSize, count = 0;
    F64 data[100000];

    //注册采集卡
    //返回初始化的卡的数字卡ID。卡ID取值范围为0 ~ 31。如果发生任何错误，则返回负错误代码。
    //Register_Card(U16 CardType, U16 card_num);
//    card=Register_Card(cardifo,0);
//    if((Err=card)<0){
//        qDebug()<<"Register_Card error=="<<Err;
//        exit(1);
//    }
//    else
//    {
//        qDebug()<<"Register_Card ok=="<<card;
//    }
    //返回系统启动时在驱动程序中为连续操作分配的内存的映射缓冲区地址。
    //分配的内存大小可以通过函数Al_InitialMemoryAllocated获得。
    //此功能不适用于单缓冲连续模拟输入操作的中(约)触发或预触发模式。
    //here to get the starting addresses of two driver DB buffers
        //    Err=AI_GetView(card,&viewAddr); //viewAddr : driver buffer
        //    if(Err<0){
        //     qDebug()<<"AI_GetView error=="<<Err;
        //     exit(1);
        //     }
        //    else
        //    {
        //        qDebug()<<"AI_GetView ok=="<<Err;
        //    }

        //     Err= AI_InitialMemoryAllocated(card, &MemSize);
        //     if(Err<0){
        //     qDebug()<<"AI_InitialMemoryAllocated error=="<<Err;
        //     exit(1);
        //     }
        //    else
        //    {
        //        qDebug()<<"AI_InitialMemoryAllocated ok=="<<Err;
        //    }
        //     Db_buf[0] = viewAddr; //1st DB buffer address
        //     Db_buf[1] = viewAddr + (MemSize * 1024 / 2); //2nd DB buffer address

     //AI_9111_Config(CardNumber执行操作的卡ID,TrigSoure连续AD转换触发源,Tirg触发模式选择,TraceCnt)
//     Err=AI_9111_Config(card, TRIG_INT_PACER, P9111_TRGMOD_SOFT, 0);
//     if(Err<0){
//     qDebug()<<"AI_9111_Config error=="<<Err;
//     exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_9111_Config ok=="<<Err;
//     }

    //AI_AsyncDblBufferMode(U16 CardNumber, BOOLEAN Enable);
    //启用或禁用双缓冲数据采集模式
//     Err = AI_AsyncDblBufferMode(card, TRUE);
//     if(Err<0){
//     qDebug()<<"AI_InitialMemoryAllocated error=="<<Err;
//     exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_InitialMemoryAllocated ok=="<<Err;
//     }
     //在执行连续A/D转换时，调用此函数以获取A/D状态。
     //I16 AI_ContStatus (U16 CardNumber, U16 *Status)
     //*Status 返回的连续Al状态。列出了各种卡类型的Status参数说明。
     //PCI-9111 bit 0=FIFO为空 1-半满 2-已满数据可能丢失 3-AD忙;A/D数据没有锁存到FIFO中 4~15未使用
//     U16 *ContStatus = nullptr;
//     Err=AI_ContStatus(card,ContStatus);
//     if(Err<0){
//       qDebug()<<"AI_ContStatus error=="<<Err;
//       exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_ContStatus ok=="<<Err;
//     }
    //
    //AI_ContReadChannel(U16 CardNumber, U16 Channel, U16 AdRange, U16 *Buffer, U32 ReadCount, F64 SampleRate, U16 SyncMode);
    //Channel(0 to 15)
    //AdRange：AD_B_10_V, AD_B_5_V, AD_B_2_5_V, AD_B_1_25_V,AD_B_0_625_V  B双极 U单极
    //*Buffer:如果启用了双缓冲模式，这个缓冲区无效
    //ReadCount读取样本通道的数量必须是4的倍数
    //SampleRate采样率
    //SyncMode采样模式 同步或异步
//     Err=AI_ContReadChannel(card,0,AD_B_10_V,NULL,400,2048,ASYNCH_OP);//
//     if(Err<0){
//       qDebug()<<"AI_ContReadChannel error=="<<Err;
//       exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_ContReadChannel ok=="<<Err;
//     }
     //读选中通道的电压数据值
     //在模拟输入通道上执行软件触发的a /D转换(模拟输入)，并将缩放后的值以伏特为单位返回电压。
     //AI_VReadChannel (U16 CardNumber, U16 Channel,U16 AdRange, F64 *voltage)
     //Channel(0 to 15)
     //AdRange:AD_B_10_V, AD_B_5_V, AD_B_2_5_V, AD_B_1_25_V,AD_B_0_625_V  B双极 U单极
     //*voltage返回测量的电压值并按比例缩放为电压单位。
//     F64 *voltage=nullptr;
//     Err=AI_VReadChannel(card,0,AD_B_10_V,voltage);
//     if(Err<0){
//       qDebug()<<"AI_VReadChannel error=="<<Err;
//       exit(1);
//     }
//     else
//     {
//       qDebug()<<"AI_VReadChannel ok=="<<Err;
//     }
    //停止异步模拟输入操作。
    //AI_AsyncClear(CardNumber,AccessCnt)
    //在不使用触发器采集模式的情况下，AccessCnt返回callingAl_AsyncClear()时已经传输的A/D数据数。
    //如果启用双缓冲模式，AccessCnt返回最后一个A/D数据在循环缓冲区中存储的位置之后的下一个位置。
    //如果accessnt超过了循环缓冲区的一半大小，调用两次Al_AsyncDblBufferTransfer来获取数据。
//    Err=AI_AsyncClear(card, &count);
//    if(Err<0){
//        qDebug()<<"AI_AsyncClear error=="<<Err;
//        exit(1);
//    }
//     else
//     {
//       qDebug()<<"AI_AsyncClear ok=="<<Err;
//     }
    //释放注册的采集卡
//     Err=Release_Card(card);
//     if(Err<0){
//     qDebug()<<"Release_Card error=="<<Err;
//     exit(1);
//     }
//     else
//     {
//       qDebug()<<"Release_Card ok=="<<Err;
//     }
    /********************软件界面*************************/
    setWindowTitle("凌华PCI9111数据采集卡采集软件");
    //设置窗口大小
    setFixedSize(1900,900);
    /********************图表界面************************/
    /***********采集通道0的波形图显示界面*************/
    cview0=new QChartView(this);
    chart0 = new QChart();
    chart0->setTitle("采集波形图");
    cview0->setChart(chart0);
    cview0->setRenderHint(QPainter::Antialiasing);
    cview0->resize(1400,430);
    series0=new QLineSeries();
    series0->setName("AI0");
    chart0->addSeries(series0);
    axsisX0=new QValueAxis();
    axsisY0=new QValueAxis();
    axsisX0->setTitleText("时间/S");
    axsisX0->setRange(0,50000);
    axsisY0->setRange(-5.0,5.0);
    axsisY0->setTitleText("电压/V");
    chart0->addAxis(axsisX0,Qt::AlignBottom);
    chart0->addAxis(axsisY0,Qt::AlignLeft);
    series0->attachAxis(axsisX0);
    series0->attachAxis(axsisY0);
    /***********采集通道1的波形图显示界面*************/
    cview1=new QChartView(this);
    chart1 = new QChart();
    chart1->setTitle("采集波形图");
    cview1->setChart(chart1);
    cview1->setRenderHint(QPainter::Antialiasing);
    cview1->move(0,410);
    cview1->resize(1400,430);
    series1=new QLineSeries();
    series1->setName("AI1");
    chart1->addSeries(series1);
    axsisX1=new QValueAxis();
    axsisY1=new QValueAxis();
    axsisX1->setTitleText("时间/S");
    axsisX1->setRange(0,50000);
    axsisY1->setRange(-5.0,5.0);
    axsisY1->setTitleText("电压/V");
    chart1->addAxis(axsisX1,Qt::AlignBottom);
    chart1->addAxis(axsisY1,Qt::AlignLeft);
    series1->attachAxis(axsisX1);
    series1->attachAxis(axsisY1);

    series0->append(10,3);
    series0->append(100,1);
    series0->append(200,4);
    series0->append(300,4);

    series1->append(10,3);
    series1->append(100,1);
    series1->append(1000,4);
    series1->append(2000,4);
}
Widget::~Widget()
{
    delete ui;
}

//打开参数设定窗口
void Widget::on_setParBtn_clicked()
{
    setData *q=new setData();
    q->show();
    this->hide();
}

