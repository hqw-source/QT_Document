#ifndef SETDATA_H
#define SETDATA_H

#include <QMainWindow>

namespace Ui {
class setData;
}

class setData : public QMainWindow
{
    Q_OBJECT

public:
    explicit setData(QWidget *parent = nullptr);
    ~setData();

private slots:

    void on_backBtn_clicked();

private:
    Ui::setData *ui;
};

#endif // SETDATA_H
