#ifndef DATAANALYSE_H
#define DATAANALYSE_H

#include <QMainWindow>
namespace Ui {
class dataAnalyse;
}

class dataAnalyse : public QMainWindow
{
    Q_OBJECT

public:
    explicit dataAnalyse(QWidget *parent = nullptr);
    ~dataAnalyse();

private slots:


    void on_backWidgetBtn_clicked();

    void on_readDataBtn_clicked();

private:
    Ui::dataAnalyse *ui;
};

#endif // DATAANALYSE_H
