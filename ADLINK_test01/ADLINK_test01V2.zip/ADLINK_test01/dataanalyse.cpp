#include "dataanalyse.h"
#include "ui_dataanalyse.h"
#include "widget.h"

dataAnalyse::dataAnalyse(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::dataAnalyse)
{
    ui->setupUi(this);
    /********************软件界面*************************/
    setWindowTitle("当前状态:凌华PCI9111数据采集卡采集软件->数据分析");
    //设置窗口大小
    setFixedSize(1600,900);

}
dataAnalyse::~dataAnalyse()
{
    delete ui;
}
void dataAnalyse::on_backWidgetBtn_clicked()
{
    this->hide();
    Widget *w=new Widget();
    w->show();
}

//保存数据按钮
void dataAnalyse::on_readDataBtn_clicked()
{

}

