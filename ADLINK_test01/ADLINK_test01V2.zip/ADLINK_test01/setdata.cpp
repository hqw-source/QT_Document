#include "setdata.h"
#include "ui_setdata.h"
#include "widget.h"

setData::setData(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::setData)
{
    ui->setupUi(this);
    /********************软件界面*************************/
    setWindowTitle("当前状态:凌华PCI9111数据采集卡采集软件->参数设定");
    //设置窗口大小
    setFixedSize(1000,900);
}
setData::~setData()
{
    delete ui;
}
//返回按钮转Widget采集界面
void setData::on_backBtn_clicked()
{
    this->hide();
    Widget *w=new Widget();
    w->show();
}
//确定按钮转Widget采集界面
void setData::on_okBtn_clicked()
{
    this->hide();
    Widget *w=new Widget();
    w->show();
    ui->Q_CheckBox->setChecked(ui->Q_CheckBox->checkState());
}

