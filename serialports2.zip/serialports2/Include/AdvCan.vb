'******************************************************************************
'                Copyright (c) 2009, Advantech Automation Corp.
'      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
'            INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
'
'      ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
'            ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
'******************************************************************************

'******************************************************************************
'
' File:    AdvCan.vb
' Created: 6/20/2007
' Revision:6/5/2009
' Version: 1.0
'          - Initial version
'          2.0
'          - Compatible with 64-bit and 32-bit system
'          2.1 (2011-5-19)
'          - Fix bug of API declaration
' Description: Defines data structures and declarations
' 
'------------------------------------------------------------------------------
Option Strict Off
Option Explicit On 
Imports System.Attribute
Imports Microsoft.Win32.SafeHandles
Imports System.Runtime.InteropServices

Public Module AdvCAN
   '****************************************************************************
   'Constant Definition
   '****************************************************************************
   Public Const CAN_MSG_LENGTH As Integer = 30              'Length of CAN_MSG in bytes
   Public Const CAN_COMMAND_LENGTH As Integer = 24          'Length of Command_par_t in bytes
   Public Const CAN_CONFIG_LENGTH As Integer = 24           'Length of Config_par_t in bytes
   Public Const CAN_CANSTATUS_LENGTH As Integer = 72        'Length of CanStatusPar_t in bytes

   '---------------------------------------------------------------------------
   'DESCRIPTION: Define Standard Baud Rate
   '---------------------------------------------------------------------------
   Public Const CAN_TIMING_10K As Integer = 10
   Public Const CAN_TIMING_20K As Integer = 20
   Public Const CAN_TIMING_50K As Integer = 50
   Public Const CAN_TIMING_100K As Integer = 100
   Public Const CAN_TIMING_125K As Integer = 125
   Public Const CAN_TIMING_250K As Integer = 250
   Public Const CAN_TIMING_500K As Integer = 500
   Public Const CAN_TIMING_800K As Integer = 800
   Public Const CAN_TIMING_1000K As Integer = 1000

   ' -----------------------------------------------------------------------------
   ' DESCRIPTION: Acceptance filter mode  
   ' -----------------------------------------------------------------------------
   Public Const PELICAN_SINGLE_FILTER As Integer = 1
   Public Const PELICAN_DUAL_FILTER As Integer = 0

   ' -----------------------------------------------------------------------------
   ' DESCRIPTION: CAN data length  
   ' -----------------------------------------------------------------------------
   Public Const DATALENGTH As Integer = 8

   ' -----------------------------------------------------------------------------
   ' DESCRIPTION: For CAN frame id. if flags of frame point out 
   ' some errors(MSG_OVR, MSG_PASSIVE, MSG_BUSOFF, MSG_BOUR), 
   ' then id of frame is equal to ERRORID 
   ' -----------------------------------------------------------------------------
   Public Const ERRORID As Integer = &HFFFFFFFF

   '--------------------------------------------------------------------------
   'DESCRIPTION: CAN Frame Flag 
   '--------------------------------------------------------------------------
   Public Const MSG_RTR As Integer = 1                      'RTR Message
   Public Const MSG_OVR As Integer = 2                      'CAN controller Msg overflow error
   Public Const MSG_EXT As Integer = 4                      'Extended message format
   Public Const MSG_SELF As Integer = 8                     'Message received from own tx
   Public Const MSG_PASSIVE As Integer = 16                 'CAN Controller in error passive
   Public Const MSG_BUSOFF As Integer = 32                  'CAN Controller Bus Off
   Public Const MSG_BOVR As Integer = 128                   'Receive buffer overflow


   '---------------------------------------------------------------------------
   'DESCRIPTION: IOCTL Command Cmd Targets
   '--------------------------------------------------------------------------
   Public Const CMD_START As Integer = 1                    'Start chip      
   Public Const CMD_STOP As Integer = 2                     'Stop chip     
   Public Const CMD_RESET As Integer = 3                    'Reset chip   
   Public Const CMD_CLEARBUFFERS As Integer = 4             'Clear the receive buffer

   '---------------------------------------------------------------------------
   'DESCRIPTION: Define IOCTL Configure cmd targets
   '--------------------------------------------------------------------------
   Public Const CONF_ACC As Integer = 0                     'Accept code and mask code
   Public Const CONF_ACCM As Integer = 1                    'Mask code  
   Public Const CONF_ACCC As Integer = 2                    'Accept code 
   Public Const CONF_TIMING As Integer = 3                  'Bit timing
   Public Const CONF_LISTEN_ONLY_MODE As Integer = 8        'For SJA1000 PeliCAN 
   Public Const CONF_SELF_RECEPTION As Integer = 9          'Self reception 
   Public Const CONF_TIMEOUT As Integer = 13                'Configure read and write timeout one time 
   Public Const CONF_ACC_FILTER As Integer = 20             'Acceptance filter mode: 1-Single, 0-Dual 

   '---------------------------------------------------------------------------
   'DESCRIPTION: Define windows  macro used in widows API
   '--------------------------------------------------------------------------
   Public Const STATUS_OK As Integer = 0
   Public Const STATUS_BUS_ERROR As Integer = 1
   Public Const STATUS_BUS_OFF As Integer = 2

   Public Const ERROR_SEM_TIMEOUT As Integer = 121
   Public Const ERROR_IO_PENDING As Integer = 997

   Public Const GENERIC_READ As Integer = &H80000000
   Public Const GENERIC_WRITE As Integer = &H40000000
   Public Const GENERIC_EXECUTE As Integer = &H20000000
   Public Const GENERIC_ALL As Integer = &H10000000

   Public Const FILE_SHARE_READ As Integer = &H1
   Public Const FILE_SHARE_WRITE As Integer = &H2
   Public Const FILE_SHARE_DELETE As Integer = &H4

   Public Const CE_RXOVER As Integer = &H1                   'Receive Queue overflow
   Public Const CE_OVERRUN As Integer = &H2                  'Receive Overrun Error
   Public Const CE_FRAME As Integer = &H8                    'Receive Framing error
   Public Const CE_BREAK As Integer = &H10                   'Break Detected

   '------------------------------------------------------------------------------
   ' DESCRIPTION: For EventMask of CanStatusPar_t
   '------------------------------------------------------------------------------
   Public Const EV_ERR As Integer = &H80                      'Line status error occurred
   Public Const EV_RXCHAR As Integer = &H1                    'Any Character received

   '****************************************************************************
   '    Structure Definition
   '****************************************************************************
   '----------------------------------------------------------------------------
   'DESCRIPTION: Package Structure Definition
    '----------------------------------------------------------------------------
    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
    Public Structure can_timeval
        Public tv_sec As Integer    'seconds 
        Public tv_msec As Integer   'milliseconds 
    End Structure
    <StructLayout(LayoutKind.Sequential, Pack:=1)> _
    Public Structure IcanMsg
        Public flags As Integer                                'Flags,indicating or controlling special message properties
        Public cob As Integer                                  'CAN object number, used in Full CAN
        Public id As Integer                                   'CAN message ID, 4 bytes
        Public TimeStamp As can_timeval                         'Time Stamp for received messages
        Public length As Short                                 'Number of bytes in the CAN message
        <MarshalAs(UnmanagedType.ByValArray, SizeConst:=8)> _
        Public data() As Byte                                  'Data, 0...8 bytes 
    End Structure
    '<StructLayout(LayoutKind.Sequential, Pack:=1)> _
    'Public Structure canmsg_t
    '    Public flags As Integer                                'Flags,indicating or controlling special message properties
    '    Public cob As Integer                                  'CAN object number, used in Full CAN
    '    Public id As Integer                                   'CAN message ID, 4 bytes
    '    Public length As Short                                 'Number of bytes in the CAN message
    '    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=8)> _
    '    Public data() As Byte                                  'Data, 0...8 bytes 
    'End Structure
    '---------------------------------------------------------------------------
    'DESCRIPTION: IOCTL code 
    '---------------------------------------------------------------------------
    Public Const CAN_IOCTL_COMMAND As Integer = &H222540
    Public Const CAN_IOCTL_CONFIG As Integer = &H222544
    Public Const CAN_IOCTL_STATUS As Integer = &H222554

    Public Const OPEN_EXISTING As Integer = 3
    Public Const FILE_ATTRIBUTE_NORMAL As Integer = &H80
    Public Const FILE_FLAG_OVERLAPPED As Integer = &H40000000

    '----------------------------------------------------------------------------
    'DESCRIPTION: Asynchronous OVERLAPPED structure
    '----------------------------------------------------------------------------
    <StructLayout(LayoutKind.Sequential)> _
    Public Structure OVERLAPPED
        Dim internalLow As IntPtr
        Dim internalHigh As IntPtr
        Dim offset As Integer
        Dim offsetHigh As Integer
        Dim hEvent As IntPtr
    End Structure

    '----------------------------------------------------------------------------
    'DESCRIPTION: Device status structure
    '----------------------------------------------------------------------------
    Public Structure COMSTAT
        Dim fCtsHold As Integer
        Dim fDsrHold As Integer
        Dim fRlsdHold As Integer
        Dim fXoffHold As Integer
        Dim fXoffSent As Integer
        Dim fEof As Integer
        Dim fTxim As Integer
        Dim fReserved As Integer
        Dim cbInQue As Integer
        Dim cbOutQue As Integer
    End Structure
    '----------------------------------------------------------------------------
    'DESCRIPTION: IOCTL Command request parameter structure 
    '----------------------------------------------------------------------------
    Public Structure Command_par_t
        Dim cmd As Integer                                     'special driver command
        Dim target As Integer                                  'special configuration target 
        Dim val1 As Integer                                    'parameter 1
        Dim val2 As Integer                                    'parameter 2 
        Dim errorv As Integer                                  'return value
        Dim retval As Integer                                  'return value
    End Structure
    '----------------------------------------------------------------------------
    'DESCRIPTION: IOCTL Config request parameter structure 
    '----------------------------------------------------------------------------
    Public Structure Config_par_t
        Dim cmd As Integer                                     'special driver command
        Dim target As Integer                                  'special configuration target 
        Dim val1 As Integer                                    'parameter 1
        Dim val2 As Integer                                    'parameter 2 
        Dim errorv As Integer                                  'return value
        Dim retval As Integer                                  'return value
    End Structure
    ' -----------------------------------------------------------------------------
    'DESCRIPTION:IOCTL Generic CAN controller status request parameter structure 
    ' -----------------------------------------------------------------------------
    Public Structure CanStatusPar_t
        Dim baud As Integer                                    'Actual bit rate 
        Dim status As Integer                                  'CAN controller status register 
        Dim error_warning_limit As Integer                     'The error warning limit 
        Dim rx_errors As Integer                               'Content of RX error counter 
        Dim tx_error As Integer                                'Content of TX error counter 
        Dim error_code As Integer                              'Content of error code register 
        Dim rx_buffer_size As Integer                          'Size of rx buffer
        Dim rx_buffer_used As Integer                          'number of messages
        Dim tx_buffer_size As Integer                          'Size of tx buffer for wince, windows not use tx buffer
        Dim tx_buffer_used As Integer                          'Number of message for wince, windows not use tx buffer s
        Dim retval As Integer                                  'Return value
        Dim type As Integer                                    'CAN controller/driver type
        Dim acceptancecode As Integer                          'Acceptance code 
        Dim acceptancemask As Integer                          'Acceptance mask 
        Dim acceptancemode As Integer                          'Acceptance Filter Mode: 1:Single 0:Dual
        Dim selfreception As Integer                           'Self reception 
        Dim readtimeout As Integer                             'Read timeout 
        Dim writetimeout As Integer                            'Write timeout 
    End Structure
    '****************************************************************************
    '    Function Definition
    '****************************************************************************
    '----------------------------------------------------------------------------
    'DESCRIPTION: Windows API Declaration
    '----------------------------------------------------------------------------
    <DllImport("kernel32.dll", SetLastError:=True)> _
    Public Function CreateFile(ByVal lpFileName As String, ByVal dwDesiredAccess As Integer, ByVal dwShareMode As Integer, ByVal lpSecurityAttributes As IntPtr, ByVal dwCreationDisposition As Integer, ByVal dwFlagsAndAttributes As Integer, ByVal hTemplateFile As IntPtr) As IntPtr
    End Function


    <DllImport("kernel32.dll", SetLastError:=True)> _
    Public Function GetOverlappedResult(ByVal hFile As IntPtr, ByVal lpOverlapped As IntPtr, ByRef nNumberOfBytesTransferred As Integer, ByVal bWait As Boolean) As Boolean
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)> _
    Public Function WaitCommEvent(ByVal hFile As Integer, ByVal Mask As IntPtr, ByVal lpOverlap As IntPtr) As Boolean
    End Function

    <DllImport("kernel32.dll")> _
    Public Function CloseHandle(ByVal hObject As IntPtr) As Boolean
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)> _
    Public Function ReadFile(ByVal hDevice As IntPtr, ByVal pbData As IntPtr, ByVal nNumberOfFramesToRead As Integer, ByRef lpNumberOfFramesRead As Integer, ByVal lpOverlapped As IntPtr) As Boolean
    End Function

    <DllImport("kernel32.dll", SetLastError:=True)> _
    Public Function WriteFile(ByVal hDevice As IntPtr, ByVal pbData As IntPtr, ByVal nNumberOfFramesToWrite As Integer, ByRef lpNumberOfFramesWritten As Integer, ByVal lpOverlapped As IntPtr) As Boolean
    End Function


    <DllImport("kernel32.dll")> _
    Public Function DeviceIoControl(ByVal hDevice As IntPtr, ByVal dwIoControlCode As Integer, ByVal lpInBuffer As IntPtr, ByVal nInBufferSize As Integer, ByVal lpOutBuffer As IntPtr, ByVal nOutBufferSize As Integer, ByRef lpBytesReturned As Integer, ByVal lpOverlapped As IntPtr) As Boolean
    End Function

    <DllImport("kernel32.dll")> _
    Public Function ClearCommError(ByVal hFile As IntPtr, ByRef lpErrors As Integer, ByRef lpStat As COMSTAT) As Boolean
    End Function

    <DllImport("kernel32.dll")> _
    Public Function GetCommMask(ByVal hFile As IntPtr, ByRef EvtMask As Integer) As Boolean
    End Function

    <DllImport("kernel32.dll")> _
    Public Function SetCommMask(ByVal hFile As IntPtr, ByVal dwEvtMask As Integer) As Boolean
    End Function

End Module
