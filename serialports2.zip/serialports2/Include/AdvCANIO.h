// #############################################################################
// *****************************************************************************
//                  Copyright (c) 2009, Advantech Automation Corp.
//      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
//               INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
//
//    ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
//               ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
// *****************************************************************************

// #############################################################################
//
// File:    AdvCANIO.h
// Created: 4/8/2009
// Version: 1.0
// Description: Implements IO functions about how to access CAN WDF driver
//
// -----------------------------------------------------------------------------
#ifndef _ADV_CAN_IO_DECL_
#define _ADV_CAN_IO_DECL_

#ifdef __cplusplus
#  define ADVCANINL        __inline
#else
#  define ADVCANINL        static
#endif

/*****************************************************************************
* Helpers
*****************************************************************************/
#ifdef _MSC_VER
   __declspec(selectany)   FARPROC *z_adv_can_apis = NULL;
#else
   static                  FARPROC *z_adv_can_apis = NULL;
#endif

#define ADV_CAN_API(T, x)  ((T)z_adv_can_apis[x])

static BOOL adv_can_lib_load()
{
   if (z_adv_can_apis == NULL) {
      HMODULE canlib = LoadLibrary(_T("AdvCan.dll"));
      z_adv_can_apis = (FARPROC *)GetProcAddress(canlib, "adv_can_apis");
   }

   return z_adv_can_apis != NULL;
}

ADVCANINL int acCanCommand(HANDLE hDevice, int cmd, ULONG val1, ULONG val2) 
{
   typedef int (WINAPI *ACFP_CMD)(HANDLE, int, ULONG, ULONG);
   return ADV_CAN_API(ACFP_CMD, 3)(hDevice, cmd, val1, val2);
}

ADVCANINL int acCanConfigure(HANDLE hDevice, int target, ULONG val1, ULONG val2)            
{
   typedef int (WINAPI *ACFP_CFG)(HANDLE, int, ULONG, ULONG);
   return ADV_CAN_API(ACFP_CFG, 4)(hDevice, target, val1, val2);
}

/*****************************************************************************
*acCanOpen
*   Open can port by name 
*Arguments:
*   name            - port name
*   synchronization - TRUE, synchronization ; FALSE, asynchronous
*Returns:
*   Handle of device 
*****************************************************************************/
ADVCANINL HANDLE acCanOpen(TCHAR *name, BOOL synchronization)
{
   typedef HANDLE (WINAPI *ACFP_OPEN)(TCHAR *, BOOL);

   if (!adv_can_lib_load()) {
      return INVALID_HANDLE_VALUE;
   }

#if defined(_UNICODE) || defined(UNICODE)
   return ADV_CAN_API(ACFP_OPEN, 1)(name, synchronization);
#else 
   return ADV_CAN_API(ACFP_OPEN, 0)(name, synchronization);
#endif
}

/*****************************************************************************
*acCanClose
*   Close can port by handle 
*Arguments:
*   hDevice - handle of device
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acCanClose(HANDLE hDevice)
{
   typedef int (WINAPI *ACFP_CLOSE)(HANDLE);

   return ADV_CAN_API(ACFP_CLOSE, 2)(hDevice);
}

/*****************************************************************************
*acEnterResetMode
*   Enter reset mode.
*Arguments:
*   hDevice - handle of device
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acEnterResetMode(HANDLE hDevice)            
{
	return acCanCommand(hDevice, CMD_STOP, 1, 1);
}

/*****************************************************************************
*acEnterWorkMode
*   Enter work mode 
*Arguments:
*   hDevice - handle of device
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acEnterWorkMode(HANDLE hDevice)              
{
   return acCanCommand(hDevice, CMD_START, 0, 0);
}

/*****************************************************************************
*acClearRxFifo
*   Clear can port rx buffer by handle 
*Arguments:
*   hDevice - handle of device
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acClearRxFifo(HANDLE hDevice)
{
   return acCanCommand(hDevice, CMD_CLEARBUFFERS, 0, 0);
}

/*****************************************************************************
*acSetBaud
*   Set baud rate of the CAN Controller.The two modes of configuring
*   baud rate are custom mode and standard mode.
*   - Custom mode
*       If Baud Rate value is user defined, driver will write the first 8
*       bit of low 16 bit in BTR0 of SJA1000.
*       The lower order 8 bit of low 16 bit will be written in BTR1 of SJA1000.
*   - Standard mode
*       Target value     BTR0      BTR1      Setting value 
*         10K            0x31      0x1c      10 
*         20K            0x18      0x1c      20 
*         50K            0x09      0x1c      50 
*        100K            0x04      0x1c      100 
*        125K            0x03      0x1c      125 
*        250K            0x01      0x1c      250 
*        500K            0x00      0x1c      500 
*        800K            0x00      0x16      800 
*       1000K            0x00      0x14      1000 
*Arguments:
*   hDevice - handle of device
*   baud    - baud rate will be set
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acSetBaud(HANDLE hDevice, unsigned int baud)
{
   return acCanConfigure(hDevice, CONF_TIMING, baud, 0);
}

/*****************************************************************************
*acSetBaudRegister
*   Configures baud rate by custom mode.
*Arguments:
*   hDevice - handle of device
*   btr0    - BTR0 register value.
*   btr1    - BTR1 register value.
*Returns:
*    =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acSetBaudRegister(HANDLE hDevice, unsigned char btr0, unsigned char btr1)
{
   return acSetBaud(hDevice, ((unsigned int)btr0 << 8) | btr1);
}

/*****************************************************************************
*acSetTimeOut
*   Set Timeout for read and write
*Arguments:
*   hDevice      - handle of device
*   readTimeOut  - ms
*   writeTimeOut - ms
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acSetTimeOut(HANDLE hDevice, ULONG readTimeOut, ULONG writeTimeOut)
{
   return acCanConfigure(hDevice, CONF_TIMEOUT, writeTimeOut, readTimeOut);
}

/*****************************************************************************
*acSetSelfReception
*   Set Self Reception mode
*Arguments:
*   hDevice - handle of device
*   self    - TRUE, open self reception; FALSE close self reception
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acSetSelfReception(HANDLE hDevice, BOOL self)
{
   return acCanConfigure(hDevice, CONF_SELF_RECEPTION, self, 0);
}

/*****************************************************************************
*acSetListenOnlyMode
*   Set listen only mode
*Arguments:
*   hDevice    - Handle of device
*   listenOnly - TRUE, open only listen mode; FALSE, close only listen mode
*Returns:
*   =0 succeeded; or <0 Failed 
*****************************************************************************/
ADVCANINL int acSetListenOnlyMode(HANDLE hDevice, BOOL listenOnly)
{
   return acCanConfigure(hDevice, CONF_LISTEN_ONLY_MODE, listenOnly, 0);
}

/*****************************************************************************
*acSetAcceptanceFilterMode
*   Set acceptance filter mode
*Arguments:
*   hDevice - Handle of device
*   mode    - PELICAN_SINGLE_FILTER, single filter mode; PELICAN_DUAL_FILTER, dule filter mode
*Returns:
*   =0 succeeded; or <0 Failed 
*****************************************************************************/
ADVCANINL int acSetAcceptanceFilterMode(HANDLE hDevice, int mode)
{
   return acCanConfigure(hDevice, CONF_ACC_FILTER, mode, 0);
}

/*****************************************************************************
*acSetAcceptanceFilterMask
*   Set acceptance filter mask of the CAN Controller
*Arguments:
*   hDevice - handle of device
*   mask    - accept mask code
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acSetAcceptanceFilterMask(HANDLE hDevice, ULONG mask)
{
   return acCanConfigure(hDevice, CONF_ACCM, mask, 0);
}

/*****************************************************************************
*acSetAcceptanceFilterCode
*   Set acceptance filter code of the CAN Controller
*Arguments:
*   hDevice - handle of device
*   code    - acceptance code
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acSetAcceptanceFilterCode(HANDLE hDevice, ULONG code)
{
   return acCanConfigure(hDevice, CONF_ACCC, code, 0);
}

/*****************************************************************************
*acSetAcceptanceFilter
*   Set acceptance filter code and mask of the CAN Controller
*Arguments:
*   hDevice - handle of device
*   code    - acceptance code
*   mask    - acceptance mask
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acSetAcceptanceFilter(HANDLE hDevice, ULONG code, ULONG mask)
{
   return acCanConfigure(hDevice, CONF_ACC, mask, code);
}

/*****************************************************************************
*acSetCommMask
*   Execute SetCommMask.
*Arguments:
*   hDevice - handle of device
*   mask    - event type
*Returns:
*   TRUE SUCCESS; or FALSE failure 
*****************************************************************************/
ADVCANINL BOOL acSetCommMask(HANDLE hDevice, ULONG mask)
{
   return SetCommMask(hDevice, mask);
}

/*****************************************************************************
*acGetCommMask
*   Execute GetCommMask.
*Arguments:
*   hDevice - handle of device
*   mask    - event type
*Returns:
*   TRUE SUCCESS; or FALSE failure 
*****************************************************************************/
ADVCANINL BOOL acGetCommMask(HANDLE hDevice, ULONG *mask)
{
   return GetCommMask(hDevice, mask);
}

/*****************************************************************************
*acGetStatus
*   Get the current status of the driver and the CAN Controller
*Arguments:
*   hDevice - handle of device
*   status  - status buffer
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acGetStatus(HANDLE hDevice, CanStatusPar_t *status)
{
   typedef int (WINAPI *ACFP_GETSTATUS)(HANDLE, CanStatusPar_t *);

   return ADV_CAN_API(ACFP_GETSTATUS, 6)(hDevice, status);
}

/*****************************************************************************
*acClearCommError
*   Execute ClearCommError of AdvCan.
*Arguments:
*   hDevice - handle of device
*   errors  - error code if the CAN Controller occur error
*Returns:
*    TRUE SUCCESS; or FALSE failure 
*****************************************************************************/
ADVCANINL BOOL acClearCommError(HANDLE hDevice, ULONG *errors)
{
   typedef int (WINAPI *ACFP_CLRERR)(HANDLE, ULONG *);

   return ADV_CAN_API(ACFP_CLRERR, 7)(hDevice, errors);
}

/*****************************************************************************
*acCanRead
*   Read can message
*Arguments:
*   hDevice - handle of device
*   msgs    - data buffer
*   count   - msg number of data buffer size
*   xferred - real MSGs have read
*   ov      - synchronization event
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acCanRead(HANDLE hDevice, IcanMsg *msgs, ULONG count, ULONG *xferred, OVERLAPPED *ov)
{
   typedef int (WINAPI *ACFP_READ)(HANDLE, IcanMsg *, ULONG, ULONG *, OVERLAPPED *);

   return ADV_CAN_API(ACFP_READ, 8)(hDevice, msgs, count, xferred, ov);
}

/*****************************************************************************
*acCanWrite
*   Write can msg
*Arguments:
*   hDevice - handle of device
*   msgs    - data buffer
*   count   - MSGs number
*   xferred - real MSGs have written
*   ov      - synchronization event
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acCanWrite(HANDLE hDevice, IcanMsg *msgs, ULONG count, ULONG *xferred, OVERLAPPED *ov)
{
   typedef int (WINAPI *ACFP_WRITE)(HANDLE, IcanMsg *, ULONG, ULONG *, OVERLAPPED *);

   return ADV_CAN_API(ACFP_WRITE, 9)(hDevice, msgs, count, xferred, ov);
}

/*****************************************************************************
*acWaitEvent
*   Wait can message or error of the CAN Controller.
*Arguments:
*   hDevice - handle of device
*   msgs    - buffer for read
*   count   - MSGs number
*   xferred - real MSGs have read
*   errors  - return error code when the CAN Controller has error
*   ov      - synchronization event
*Returns:
*   =0 SUCCESS; or <0 failure 
*****************************************************************************/
ADVCANINL int acWaitEvent(HANDLE hDevice, IcanMsg *msgs, ULONG count, ULONG *xferred, ULONG *errors, OVERLAPPED *ov)
{
   typedef int (WINAPI *ACFP_WAITEVENT)(HANDLE, IcanMsg *, ULONG, ULONG *, ULONG *, OVERLAPPED *);

   return ADV_CAN_API(ACFP_WAITEVENT, 10)(hDevice, msgs, count, xferred, errors, ov);
}

#endif