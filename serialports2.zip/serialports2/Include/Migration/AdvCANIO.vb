'******************************************************************************
'                Copyright (c) 2009, Advantech Automation Corp.
'      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
'            INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
'
'      ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
'            ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
'******************************************************************************

'******************************************************************************
'
' File:    AdvCANIO.vb
' Created: 01/13/2021
' Revision:01/13/2021
' Version: 1.0
'          - Initial version
'          2.0
'          - Compatible with 64-bit and 32-bit system
'          2.1 (2011-5-19)
'          - Fix bug of  WaitCommEvent
' Description: Implements IO function about how to access CAN WDM&CE driver
' 
'------------------------------------------------------------------------------
Option Strict Off
Option Explicit On
Imports System
Imports System.Threading
Imports System.Attribute
Imports Microsoft.Win32.SafeHandles
Imports System.Runtime.InteropServices

Public Class AdvCANIO
   Private hDevice As IntPtr                                                    'Device handle
   Private orgWriteBuf As IntPtr                                                'Unmanaged buffer for write
   Private orgReadBuf As IntPtr                                                 'Unmanaged buffer for read
   Private lpCommandBuffer As IntPtr                                            'Unmanaged buffer for Command
   Private lpConfigBuffer As IntPtr                                             'Unmanaged buffer for Config
   Private lpStatusBuffer As IntPtr                                             'Unmanaged buffer for Status
   Private Command As Command_par_t = New Command_par_t()                       'Managed buffer for Command
   Private Config As Config_par_t = New Config_par_t()                          'Managed buffer for Cofig
   Private OutLen As Integer                                                    'Out data length for DeviceIoControl
   Private MaxReadMsgNumber As Integer                                          'Max number of message in unmanaged buffer for read 
   Private MaxWriteMsgNumber As Integer                                         'Max number of message in unmanaged buffer for write
   Private OS_TYPE As Integer = IntPtr.Size                                     'For judge x86 or x64
   Private EventCode As Integer = 0                                             'Event code for WaitCommEvent
   Private lpEventCode As IntPtr = IntPtr.Zero                                  'unmanaged buffer for Event code
   Private INVALID_HANDLE_VALUE As IntPtr = System.IntPtr.Zero                  'Invalid handle
   Public Const SUCCESS As Integer = 0                                          'Status definition : success
   Public Const OPERATION_ERROR As Integer = -1                                 'Status definition : device error or parameter error
    Public Const TIME_OUT As Integer = -2                                        'Status definition : time out
    Private events As Win32Events
    Private ioctlOvr As Win32Ovrlap
    Private ioctlEvent As ManualResetEvent
    Private txOvr As Win32Ovrlap
    Private writeEvent As ManualResetEvent
    Private rxOvr As Win32Ovrlap
    Private eventOvr As Win32Ovrlap
    Private readEvent As AutoResetEvent


   Sub New()
        ioctlEvent = New ManualResetEvent(False)
        ioctlOvr = New Win32Ovrlap(ioctlEvent.SafeWaitHandle.DangerousGetHandle())

        writeEvent = New ManualResetEvent(False)
        txOvr = New Win32Ovrlap(writeEvent.SafeWaitHandle.DangerousGetHandle())

        readEvent = New AutoResetEvent(False)
        rxOvr = New Win32Ovrlap(readEvent.SafeWaitHandle.DangerousGetHandle())

        eventOvr = New Win32Ovrlap(readEvent.SafeWaitHandle.DangerousGetHandle())
        events = New Win32Events(eventOvr.memPtr)


        lpCommandBuffer = Marshal.AllocHGlobal(CAN_COMMAND_LENGTH)
        lpConfigBuffer = Marshal.AllocHGlobal(CAN_CONFIG_LENGTH)
        lpStatusBuffer = Marshal.AllocHGlobal(CAN_CANSTATUS_LENGTH)
        lpEventCode = Marshal.AllocHGlobal(Marshal.SizeOf(EventCode))
        Marshal.StructureToPtr(EventCode, lpEventCode, True)
    End Sub

   Protected Overrides Sub Finalize()
      If hDevice <> INVALID_HANDLE_VALUE Then
         CloseHandle(hDevice)
         Thread.Sleep(100)

         Marshal.FreeHGlobal(orgWriteBuf)
         Marshal.FreeHGlobal(orgReadBuf)
         Marshal.FreeHGlobal(lpCommandBuffer)
         Marshal.FreeHGlobal(lpConfigBuffer)
         Marshal.FreeHGlobal(lpStatusBuffer)
         Marshal.FreeHGlobal(lpEventCode)

         hDevice = INVALID_HANDLE_VALUE
      End If
   End Sub


   '*****************************************************************************
   '
   '    acCanOpen
   '
   '    Purpose:
   '        open can port by name 
   '		
   '
   '    Arguments:
   '        PortName                - port name
   '        synchronization         - True, synchronization ; False, asynchronous
   '        MsgNumberOfReadBuffer   - message number of read intptr
   '        MsgNumberOfWriteBuffer  - message number of write intptr
   '    Returns:
   '        =0 SUCCESS; or <0 failure 
   '
   '****************************************************************************
   Public Function acCanOpen(ByVal CanPortName As String, ByVal synchronization As Boolean, ByVal MsgNumberOfReadBuffer As Integer, ByVal MsgNumberOfWriteBuffer As Integer) As Integer
      CanPortName = "\\.\" + CanPortName
      If synchronization Then
         hDevice = CreateFile(CanPortName, GENERIC_READ + GENERIC_WRITE, 0, Nothing, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0)                       'Open the CAN port in synchronous mode
      Else
         hDevice = CreateFile(CanPortName, GENERIC_READ + GENERIC_WRITE, 0, Nothing, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL + FILE_FLAG_OVERLAPPED, 0) 'Open the CAN port in asynchronous mode
      End If
      If hDevice.ToInt32 = -1 Then
         hDevice = INVALID_HANDLE_VALUE
         Return OPERATION_ERROR
      End If

      If hDevice = INVALID_HANDLE_VALUE Then
         Return OPERATION_ERROR
      Else
         MaxReadMsgNumber = MsgNumberOfReadBuffer
         MaxWriteMsgNumber = MsgNumberOfWriteBuffer
         orgReadBuf = Marshal.AllocHGlobal(CAN_MSG_LENGTH * MsgNumberOfReadBuffer)
         orgWriteBuf = Marshal.AllocHGlobal(CAN_MSG_LENGTH * MsgNumberOfWriteBuffer)
         Return SUCCESS
      End If
   End Function

   '*****************************************************************************
   '
   '    acCanClose
   '
   '    Purpose:
   '        Close can port 
   '		
   '
   '    Arguments:
   '
   '    Returns:
   '        =0 SUCCESS; or <0 failure 
   '
   '****************************************************************************
   Public Function acCanClose() As Integer
      If hDevice <> INVALID_HANDLE_VALUE Then
         CloseHandle(hDevice)
         Thread.Sleep(100)
         Marshal.FreeHGlobal(orgWriteBuf)
         Marshal.FreeHGlobal(orgReadBuf)

         hDevice = INVALID_HANDLE_VALUE
      End If

      Return SUCCESS
   End Function

   '*****************************************************************************
   '
   '    acEnterResetMode
   '
   '    Purpose:
   '        Enter reset mode.
   '		
   '
   '    Arguments:
   '
   '    Returns:
   '        =0 SUCCESS; or <0 failure 
   '
   '****************************************************************************
   Public Function acEnterResetMode() As Integer
      Dim flag As Boolean
        Command.cmd = CMD_STOP
        Command.val1 = 1
        Command.val2 = 1
        Marshal.StructureToPtr(Command, lpCommandBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_COMMAND, lpCommandBuffer, CAN_COMMAND_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acEnterWorkMode
    '
    '    Purpose:
    '        Enter work mode.
    '		
    '
    '    Arguments:
    '
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acEnterWorkMode() As Integer
        Dim flag As Boolean
        Command.cmd = CMD_START
        Marshal.StructureToPtr(Command, lpCommandBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_COMMAND, lpCommandBuffer, CAN_COMMAND_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acClearRxFifo
    '
    '    Purpose:
    '        Clear can port receive buffer 
    '		
    '
    '    Arguments:
    '
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acClearRxFifo() As Integer
        Dim flag As Boolean
        Command.cmd = CMD_CLEARBUFFERS
        Marshal.StructureToPtr(Command, lpCommandBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_COMMAND, lpCommandBuffer, CAN_COMMAND_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetBaud
    '
    '    Purpose:
    '		Set baudrate of the CAN Controller.The two modes of configuring
    '     baud rate are custom mode and standard mode.
    '     -   Custom mode
    '         If Baud Rate value is user defined, driver will write the first 8
    '         bit of low 16 bit in BTR0 of SJA1000.
    '         The lower order 8 bit of low 16 bit will be written in BTR1 of SJA1000.
    '     -   Standard mode
    '         Target value     BTR0      BTR1      Setting value 
    '           10K            0x31      0x1c      10 
    '           20K            0x18      0x1c      20 
    '           50K            0x09      0x1c      50 
    '          100K            0x04      0x1c      100 
    '          125K            0x03      0x1c      125 
    '          250K            0x01      0x1c      250 
    '          500K            0x00      0x1c      500 
    '          800K            0x00      0x16      800 
    '         1000K            0x00      0x14      1000 
    '		
    '
    '    Arguments:
    '        BaudRateValue             - baudrate will be set
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acSetBaud(ByVal BaudRateValue As Integer) As Integer
        Dim flag As Boolean
        Config.target = CONF_TIMING
        Config.val1 = BaudRateValue
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetBaudRegister
    '
    '    Purpose:
    '        Configures baud rate by custom mode.
    '		
    '
    '    Arguments:
    '        Btr0           - BTR0 register value.
    '        Btr1           - BTR1 register value.
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acSetBaudRegister(ByVal Btr0 As Byte, ByVal Btr1 As Byte) As Integer
        Dim BaudRateValue As Integer = Btr0 * 256 + Btr1
        Return acSetBaud(BaudRateValue)
    End Function

    '*****************************************************************************
    '
    '    acSetTimeOut
    '
    '    Purpose:
    '        Set timeout for read and write  
    '		
    '
    '    Arguments:
    '        ReadTimeOutValue                   - ms
    '        WriteTimeOutValue                  - ms
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acSetTimeOut(ByVal ReadTimeOutValue As Integer, ByVal WriteTimeOutValue As Integer) As Integer
        Dim flag As Boolean
        Config.target = CONF_TIMEOUT
        Config.val1 = WriteTimeOutValue
        Config.val2 = ReadTimeOutValue
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetSelfReception
    '
    '    Purpose:
    '        Set support for self reception 
    '		
    '
    '    Arguments:
    '        SelfFlag        - True, open self reception; False, close self reception
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '*****************************************************************************
    Public Function acSetSelfReception(ByVal SelfFlag As Boolean) As Integer
        Dim flag As Boolean
        Config.target = CONF_SELF_RECEPTION
        If SelfFlag Then
            Config.val1 = 1
        Else
            Config.val1 = 0
        End If
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetListenOnlyMode
    '
    '    Purpose:
    '        Set listen only mode of the CAN Controller
    '	
    '
    '    Arguments:
    '        ListenOnly           - True, open only listen mode; False, close only listen mode
    '    Returns:
    '        =0 succeeded; or <0 Failed 
    '
    '*****************************************************************************
    Public Function acSetListenOnlyMode(ByVal ListenOnly As Boolean) As Integer
        Dim flag As Boolean
        Config.target = CONF_LISTEN_ONLY_MODE
        If ListenOnly Then
            Config.val1 = 1
        Else
            Config.val1 = 0
        End If
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetAcceptanceFilterMode
    '
    '    Purpose:
    '        Set acceptance filter mode of the CAN Controller
    '		
    '
    '    Arguments:
    '        FilterMode     - PELICAN_SINGLE_FILTER, single filter mode; PELICAN_DUAL_FILTER, dule filter mode
    '    Returns:
    '        =0 succeeded; or <0 Failed 
    '
    '*****************************************************************************
    Public Function acSetAcceptanceFilterMode(ByVal FilterMode As Integer) As Integer
        Dim flag As Boolean
        Config.target = CONF_ACC_FILTER
        Config.val1 = FilterMode
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetAcceptanceFilterMask
    '
    '    Purpose:
    '        Set acceptance filter mask of the CAN Controller
    '		
    '
    '    Arguments:
    '        Mask              - acceptance filter mask
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '*****************************************************************************
    Public Function acSetAcceptanceFilterMask(ByVal Mask As Integer) As Integer
        Dim flag As Boolean
        Config.target = CONF_ACCM
        Config.val1 = Mask
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetAcceptanceFilterCode
    '
    '    Purpose:
    '        Set acceptance filter code of the CAN Controller
    '		
    '
    '    Arguments:
    '        Code              - acceptance filter code
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '*****************************************************************************
    Public Function acSetAcceptanceFilterCode(ByVal Code As Integer) As Integer
        Dim flag As Boolean
        Config.target = CONF_ACCC
        Config.val1 = Code
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acSetAcceptanceFilter
    '
    '    Purpose:
    '        Set acceptance filter code and mask of the CAN Controller 
    '		
    '
    '    Arguments:
    '        Mask              - acceptance filter mask
    '        Code              - acceptance filter code
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acSetAcceptanceFilter(ByVal Mask As Integer, ByVal Code As Integer) As Integer
        Dim flag As Boolean
        Config.target = CONF_ACC
        Config.val1 = Mask
        Config.val2 = Code
        Marshal.StructureToPtr(Config, lpConfigBuffer, True)
        flag = DeviceIoControl(hDevice, CAN_IOCTL_CONFIG, lpConfigBuffer, CAN_CONFIG_LENGTH, Nothing, 0, OutLen, Nothing)
        If flag Then
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acGetStatus
    '
    '    Purpose:
    '        Get the current status of the driver and the CAN Controller
    '		
    '
    '    Arguments:
    '        Status   			- status buffer
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acGetStatus(ByRef Status As CanStatusPar_t) As Integer
        Dim flag As Boolean
        flag = DeviceIoControl(hDevice, CAN_IOCTL_STATUS, Nothing, 0, lpStatusBuffer, CAN_CANSTATUS_LENGTH, OutLen, Nothing)
        If flag Then
            Status = (Marshal.PtrToStructure(lpStatusBuffer, GetType(CanStatusPar_t)))
            Return SUCCESS
        End If

        Return OPERATION_ERROR
    End Function

    '*****************************************************************************
    '
    '    acCanWrite
    '
    '    Purpose:
    '        Write can msg
    '		
    '
    '    Arguments:
    '        msgWrite               - managed buffer for write
    '        nWriteCount            - msg number for write
    '        pulNumberofWritten     - real msgs have written
    '
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '*****************************************************************************
    Public Function acCanWrite(ByVal msgWrite() As canmsg_t, ByVal nWriteCount As Integer, ByRef pulNumberofWritten As Integer) As Integer
        Dim dwErr As Integer
        Dim nRet As Integer = OPERATION_ERROR
        Dim i As Integer
        Dim pulByteofWrite As Integer

        If nWriteCount > MaxWriteMsgNumber Then
            nWriteCount = MaxWriteMsgNumber
        End If

        pulNumberofWritten = 0
        'Copy data from managed structure to unmanaged buffer
        For i = 0 To nWriteCount - 1
            If OS_TYPE = 8 Then
                Marshal.StructureToPtr(msgWrite(i), New IntPtr(orgWriteBuf.ToInt64() + (CAN_MSG_LENGTH * i)), True)
            Else
                Marshal.StructureToPtr(msgWrite(i), New IntPtr(orgWriteBuf.ToInt32() + (CAN_MSG_LENGTH * i)), True)
            End If
        Next i
        nRet = WriteFile(hDevice, orgWriteBuf, nWriteCount * CAN_MSG_LENGTH, pulByteofWrite, txOvr.memPtr)       'Send one frame
        If nRet Then
            pulNumberofWritten = pulByteofWrite / CAN_MSG_LENGTH
            If (nWriteCount > pulNumberofWritten) Then
                nRet = TIME_OUT                             'Package sending timeout
            Else
                nRet = SUCCESS                              'Package sending ok
            End If
        Else
            dwErr = Marshal.GetLastWin32Error()
            If dwErr = ERROR_IO_PENDING Then
                If GetOverlappedResult(hDevice, txOvr.memPtr, pulByteofWrite, True) Then
                    pulNumberofWritten = pulByteofWrite / CAN_MSG_LENGTH
                    If nWriteCount > pulNumberofWritten Then
                        nRet = TIME_OUT                   'Package sending timeout
                    Else
                        nRet = SUCCESS                        'Package sending ok
                    End If
                Else
                    nRet = OPERATION_ERROR                         'Package sending error
                End If
            Else
                nRet = OPERATION_ERROR                           'Package sending error
            End If
        End If

        Return nRet
    End Function

    '*****************************************************************************
    '
    '    acCanRead
    '
    '    Purpose:
    '        Read can message.
    '		
    '
    '    Arguments:
    '        msgRead           - managed buffer for read
    '        nReadCount        - msg number that unmanaged buffer can preserve
    '        pulNumberofRead   - real msgs have read
    '		
    '    Returns:
    '        =0 SUCCESS; or <0 failure 
    '
    '****************************************************************************
    Public Function acCanRead(ByVal msgRead() As canmsg_t, ByVal nReadCount As Integer, ByRef pulNumberofRead As Integer) As Integer
        Dim nRet As Integer = OPERATION_ERROR
        Dim dwErr As Integer
        Dim i As Integer
        Dim pulByteofRead As Integer

        If nReadCount > MaxReadMsgNumber Then
            nReadCount = MaxReadMsgNumber
        End If
        nRet = ReadFile(hDevice, orgReadBuf, nReadCount * CAN_MSG_LENGTH, pulByteofRead, rxOvr.memPtr)
        If nRet Then
            pulNumberofRead = pulByteofRead / CAN_MSG_LENGTH
            If pulNumberofRead = 0 Then
                nRet = TIME_OUT
            End If
            If pulNumberofRead > 0 Then
                For i = 0 To pulNumberofRead - 1
                    If OS_TYPE = 8 Then
                        msgRead(i) = Marshal.PtrToStructure(New IntPtr(orgReadBuf.ToInt64() + CAN_MSG_LENGTH * i), GetType(canmsg_t))
                    Else
                        msgRead(i) = Marshal.PtrToStructure(New IntPtr(orgReadBuf.ToInt32() + CAN_MSG_LENGTH * i), GetType(canmsg_t))
                    End If

                Next i
                nRet = SUCCESS
            End If
        Else
            dwErr = Marshal.GetLastWin32Error()
            If dwErr = ERROR_IO_PENDING Then
                If GetOverlappedResult(hDevice, rxOvr.memPtr, pulByteofRead, True) Then
                    pulNumberofRead = pulByteofRead / CAN_MSG_LENGTH
                    If pulNumberofRead = 0 Then
                        nRet = TIME_OUT
                    End If
                    If pulNumberofRead > 0 Then
                        For i = 0 To pulNumberofRead - 1
                            If OS_TYPE = 8 Then
                                msgRead(i) = Marshal.PtrToStructure(New IntPtr(orgReadBuf.ToInt64() + CAN_MSG_LENGTH * i), GetType(canmsg_t))
                            Else
                                msgRead(i) = Marshal.PtrToStructure(New IntPtr(orgReadBuf.ToInt32() + CAN_MSG_LENGTH * i), GetType(canmsg_t))
                            End If
                        Next i
                        nRet = SUCCESS
                    End If
                Else
                    nRet = OPERATION_ERROR                      'Package receiving error
                End If
            Else
                nRet = OPERATION_ERROR                         'Package receiving error
            End If
        End If

        Return nRet
    End Function

   '*****************************************************************************
   '
   '    acClearCommError
   '
   '    Purpose:
   '        Execute ClearCommError of AdvCan.
   '		
   '
   '    Arguments:
   '        ErrorCode    - error code if the CAN Controller occur error
   ' 
   ' 
   '    Returns:
   '        True SUCCESS; or False failure 
   '
   '****************************************************************************
   Public Function acClearCommError(ByRef ErrorCode As Integer) As Boolean
      Dim lpState As COMSTAT = New COMSTAT()
      Return ClearCommError(hDevice, ErrorCode, lpState)
   End Function

   '*****************************************************************************
   '
   '    acSetCommMask
   '
   '    Purpose:
   '        Execute SetCommMask of AdvCan.
   '		
   '
   '    Arguments:
   '        EvtMask          - event type
   ' 
   ' 
   '    Returns:
   '    True SUCCESS; or False failure  
   '
   '*****************************************************************************
   Public Function acSetCommMask(ByVal EvtMask As Integer) As Boolean
        Return SetCommMask(hDevice, EvtMask)
        If (SetCommMask(hDevice, EvtMask) = False) Then
            Return False
        End If
        Marshal.WriteInt32(events.evPtr, 0)
        Return True
    End Function

   '*****************************************************************************
   '
   '    acGetCommMask
   '
   '    Purpose:
   '        Execute GetCommMask of AdvCan.
   '		
   '
   '    Arguments:
   '        EvtMask         - event type
   ' 
   ' 
   '    Returns:
   '        True SUCCESS; or False failure 
   '
   '*****************************************************************************
   Public Function acGetCommMask(ByVal EvtMask As Integer) As Boolean
      Return GetCommMask(hDevice, EvtMask)
   End Function

   '*****************************************************************************
   '
   '    acWaitEvent
   '
   '    Purpose:
   '        Wait can message or error of the CAN Controller.
   '		
   '
   '    Arguments:
   '        msgRead           - managed buffer for read
   '        nReadCount        - msg number that unmanaged buffer can preserve
   '        pulNumberofRead   - real msgs have read
   '        ErrorCode         - return error code when the CAN Controller has error
   ' 
   '    Returns:
   '        =0 SUCCESS; or <0 failure 
   '
   '****************************************************************************
   Public Function acWaitEvent(ByVal msgRead() As canmsg_t, ByVal nReadCount As Integer, ByRef pulNumberofRead As Integer, ByRef ErrorCode As Integer) As Integer
      Dim nRet As Integer
      Dim dwErr As Integer
        pulNumberofRead = 0
        ErrorCode = 0
      nRet = OPERATION_ERROR
        If WaitCommEvent(hDevice, events.evPtr, events.olPtr) = True Then
            EventCode = Marshal.ReadInt32(events.evPtr, 0)
            If EventCode And EV_RXCHAR Then
                nRet = acCanRead(msgRead, nReadCount, pulNumberofRead)                'Read data
            End If
            If EventCode And EV_ERR Then
                nRet = OPERATION_ERROR
                acClearCommError(ErrorCode)
            End If
        Else
            dwErr = Marshal.GetLastWin32Error()
            If ERROR_IO_PENDING = dwErr Then
                If GetOverlappedResult(hDevice, eventOvr.memPtr, pulNumberofRead, True) Then
                    EventCode = Marshal.ReadInt32(events.evPtr, 0)
                    If EventCode And EV_RXCHAR Then
                        nRet = acCanRead(msgRead, nReadCount, pulNumberofRead)                'Read data
                    End If
                    If EventCode And EV_ERR Then
                        nRet = OPERATION_ERROR
                        acClearCommError(ErrorCode)
                    End If
                End If
            End If
        End If

      Return nRet
   End Function
End Class
Public Class Win32Events

    Sub New(ByVal ol As IntPtr)
        olPtr = ol
        evPtr = Marshal.AllocHGlobal(Marshal.SizeOf(intSize))
        Marshal.WriteInt32(evPtr, 0)
    End Sub

    Protected Overrides Sub Finalize()
        Marshal.FreeHGlobal(evPtr)
    End Sub

    Public evPtr As IntPtr
    Public olPtr As IntPtr
    Public intSize As Integer
End Class

Public Class Win32Ovrlap
    Sub New(ByVal evHandle As IntPtr)
        ol = New AdvCAN.OVERLAPPED()
        ol.offset = 0
        ol.offsetHigh = 0
        ol.hEvent = evHandle
        If (evHandle <> IntPtr.Zero) Then
            memPtr = Marshal.AllocHGlobal(Marshal.SizeOf(ol))
            Marshal.StructureToPtr(ol, memPtr, False)
        End If
    End Sub

    Protected Overrides Sub Finalize()
        If (memPtr <> IntPtr.Zero) Then
            Marshal.FreeHGlobal(memPtr)
        End If
    End Sub

    Public memPtr As IntPtr
    Public ol As AdvCan.OVERLAPPED
End Class
