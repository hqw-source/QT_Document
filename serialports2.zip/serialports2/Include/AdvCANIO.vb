'******************************************************************************
'                Copyright (c) 2009, Advantech Automation Corp.
'      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
'            INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
'
'      ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
'            ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
'******************************************************************************

'******************************************************************************
'
' File:    AdvCANIO.vb
' Created: 4/8/2009
' Revision:6/5/2009
' Version: 1.0
'          - Initial version
'          2.0
'          - Compatible with 64-bit and 32-bit system
'          2.1 (2011-5-19)
'          - Fix bug of  WaitCommEvent
' Description: Implements IO function about how to access CAN WDM&CE driver
' 
'------------------------------------------------------------------------------
Option Strict Off
Option Explicit On
Imports System
Imports System.Threading
Imports System.Attribute
Imports Microsoft.Win32.SafeHandles
Imports System.Runtime.InteropServices

Public Class AdvCANIO
   Public Const SUCCESS As Integer = 0                           'Status definition : success
   Public Const OPERATION_ERROR As Integer = -1                  'Status definition : device error or parameter error
   Public Const TIME_OUT As Integer = -2                         'Status definition : time out

   'Device handle
   Private hDevice As IntPtr

   'Message send
   Private MAX_TX_NUMBER As Integer                              'Max number of message in unmanaged buffer for write
   Private txEvent As AutoResetEvent
   Private txOvlap As NativeOverlapped

   'Message receive
   Private MAX_RX_NUMBER As Integer                              'Max number of message in unmanaged buffer for read 
   Private rxEvent As AutoResetEvent
   Private rxOvlap As NativeOverlapped

   'Event overlap
   Private evOvlap As NativeOverlapped

   Sub New()
      txEvent = New AutoResetEvent(False)
      txOvlap = New NativeOverlapped()
      txOvlap.EventHandle = txEvent.SafeWaitHandle.DangerousGetHandle()

      rxEvent = New AutoResetEvent(False)
      rxOvlap = New NativeOverlapped()
      rxOvlap.EventHandle = rxEvent.SafeWaitHandle.DangerousGetHandle()

      evOvlap = New NativeOverlapped()
      evOvlap.EventHandle = rxEvent.SafeWaitHandle.DangerousGetHandle()
   End Sub

   Protected Overrides Sub Finalize()
      If hDevice <> System.IntPtr.Zero Then
         CloseHandle(hDevice)
         Thread.Sleep(100)

         hDevice = System.IntPtr.Zero
      End If
   End Sub


   '*****************************************************************************
   'acCanOpen
   '   open can port by name 
   'Arguments:
   '   name                    - port name
   '   synchronization         - True, synchronization ; False, asynchronous
   '   MsgNumberOfReadBuffer   - message number of read intptr
   '   MsgNumberOfWriteBuffer  - message number of write intptr
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acCanOpen(ByVal name As String, ByVal synchronization As Boolean, ByVal MsgNumberOfReadBuffer As Integer, ByVal MsgNumberOfWriteBuffer As Integer) As Integer
      hDevice = acCanOpenW(name, synchronization)
      If hDevice.ToInt32 = -1 Then
         hDevice = System.IntPtr.Zero
         Return OPERATION_ERROR
      Else
         MAX_RX_NUMBER = MsgNumberOfReadBuffer
         MAX_TX_NUMBER = MsgNumberOfWriteBuffer
         Return SUCCESS
      End If
   End Function

   '*****************************************************************************
   'acCanClose
   '   Close can port 
   'Arguments:
   '
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acCanClose() As Integer
      acCanClose(hDevice)
      hDevice = System.IntPtr.Zero
      Return SUCCESS
   End Function

   '*****************************************************************************
   'acEnterResetMode
   '   Enter reset mode.
   'Arguments:
   '
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acEnterResetMode() As Integer
      Return acCanCommand(hDevice, CMD_STOP, 1, 1)
   End Function

   '*****************************************************************************
   'acEnterWorkMode
   '   Enter work mode.
   'Arguments:
   '
   'Returns:
   '  =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acEnterWorkMode() As Integer
      Return acCanCommand(hDevice, CMD_START, 0, 0)
   End Function

   '*****************************************************************************
   'acClearRxFifo
   '   Clear can port receive buffer 
   'Arguments:
   '
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acClearRxFifo() As Integer
      Return acCanCommand(hDevice, CMD_CLEARBUFFERS, 0, 0)
   End Function

   '*****************************************************************************
   'acSetBaud
   '   Set baud rate of the CAN Controller.The two modes of configuring
   '   baud rate are custom mode and standard mode.
   '   - Custom mode
   '     If Baud Rate value is user defined, driver will write the first 8
   '     bit of low 16 bit in BTR0 of SJA1000.
   '     The lower order 8 bit of low 16 bit will be written in BTR1 of SJA1000.
   '   - Standard mode
   '     Target value     BTR0      BTR1      Setting value 
   '       10K            0x31      0x1c      10 
   '       20K            0x18      0x1c      20 
   '       50K            0x09      0x1c      50 
   '      100K            0x04      0x1c      100 
   '      125K            0x03      0x1c      125 
   '      250K            0x01      0x1c      250 
   '      500K            0x00      0x1c      500 
   '      800K            0x00      0x16      800 
   '     1000K            0x00      0x14      1000 
   '
   'Arguments:
   '    baud - baud rate will be set
   'Returns:
   '    =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acSetBaud(ByVal baud As Integer) As Integer
      Return acCanConfigure(hDevice, CONF_TIMING, baud, 0)
   End Function

   '*****************************************************************************
   'acSetBaudRegister
   '   Configures baud rate by custom mode.
   'Arguments:
   '   btr0 - BTR0 register value.
   '   btr1 - BTR1 register value.
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acSetBaudRegister(ByVal btr0 As Byte, ByVal btr1 As Byte) As Integer
      Dim baud As Integer = btr0 * 256 + btr1
      Return acSetBaud(baud)
   End Function

   '*****************************************************************************
   'acSetTimeOut
   '   Set timeout for read and write  
   'Arguments:
   '   readTimeOut  - ms
   '   writeTimeOut - ms
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acSetTimeOut(ByVal readTimeOut As Integer, ByVal writeTimeOut As Integer) As Integer
      Return acCanConfigure(hDevice, CONF_TIMEOUT, writeTimeOut, readTimeOut)
   End Function

   '*****************************************************************************
   'acSetSelfReception
   '   Set support for self reception 
   'Arguments:
   '   self - True, open self reception; False, close self reception
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '*****************************************************************************
   Public Function acSetSelfReception(ByVal self As Boolean) As Integer
      Return acCanConfigure(hDevice, CONF_SELF_RECEPTION, self, 0)
   End Function

   '*****************************************************************************
   'acSetListenOnlyMode
   '   Set listen only mode of the CAN Controller
   'Arguments:
   '   listenOnly - True, open only listen mode; False, close only listen mode
   'Returns:
   '   =0 succeeded; or <0 Failed 
   '*****************************************************************************
   Public Function acSetListenOnlyMode(ByVal listenOnly As Boolean) As Integer
      Return acCanConfigure(hDevice, CONF_LISTEN_ONLY_MODE, listenOnly, 0)
   End Function

   '*****************************************************************************
   'acSetAcceptanceFilterMode
   '   Set acceptance filter mode of the CAN Controller
   'Arguments:
   '   mode - PELICAN_SINGLE_FILTER, single filter mode; PELICAN_DUAL_FILTER, dule filter mode
   'Returns:
   '   =0 succeeded; or <0 Failed 
   '*****************************************************************************
   Public Function acSetAcceptanceFilterMode(ByVal mode As Integer) As Integer
      Return acCanConfigure(hDevice, CONF_ACC_FILTER, mode, 0)
   End Function

   '*****************************************************************************
   'acSetAcceptanceFilterMask
   '   Set acceptance filter mask of the CAN Controller
   'Arguments:
   '   mask - acceptance filter mask
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '*****************************************************************************
   Public Function acSetAcceptanceFilterMask(ByVal mask As Integer) As Integer
      Return acCanConfigure(hDevice, CONF_ACCM, mask, 0)
   End Function

   '*****************************************************************************
   'acSetAcceptanceFilterCode
   '   Set acceptance filter code of the CAN Controller
   'Arguments:
   '   code              - acceptance filter code
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '*****************************************************************************
   Public Function acSetAcceptanceFilterCode(ByVal code As Integer) As Integer
      Return acCanConfigure(hDevice, CONF_ACCC, code, 0)
   End Function

   '*****************************************************************************
   'acSetAcceptanceFilter
   '   Set acceptance filter code and mask of the CAN Controller 
   'Arguments:
   '   mask - acceptance filter mask
   '   code - acceptance filter code
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acSetAcceptanceFilter(ByVal mask As Integer, ByVal code As Integer) As Integer
      Return acCanConfigure(hDevice, CONF_ACC, mask, code)
   End Function

   '*****************************************************************************
   'acSetCommMask
   '   Execute SetCommMask of AdvCan.
   'Arguments:
   '   mask - event type
   'Returns:
   '   True SUCCESS; or False failure  
   '*****************************************************************************
   Public Function acSetCommMask(ByVal mask As Integer) As Boolean
      Return SetCommMask(hDevice, mask)
   End Function

   '*****************************************************************************
   'acGetCommMask
   '   Execute GetCommMask of AdvCan.
   'Arguments:
   '   mask - event type
   'Returns:
   '   True SUCCESS; or False failure 
   '*****************************************************************************
   Public Function acGetCommMask(ByVal mask As Integer) As Boolean
      Return GetCommMask(hDevice, mask)
   End Function

   '*****************************************************************************
   'acGetStatus
   '   Get the current status of the driver and the CAN Controller
   'Arguments:
   '   status - status buffer
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acGetStatus(ByRef status As CanStatusPar_t) As Integer
      Return acGetStatus(hDevice, status)
   End Function

   '*****************************************************************************
   'acClearCommError
   '   Execute ClearCommError of AdvCan.
   'Arguments:
   '   errors - error code if the CAN Controller occur error
   'Returns:
   '   True SUCCESS; or False failure 
   '****************************************************************************
   Public Function acClearCommError(ByRef errors As Integer) As Boolean
      Return acClearCommError(hDevice, errors)
   End Function

   '*****************************************************************************
   'acCanRead
   '   Read can message.
   'Arguments:
   '   msgs    - managed buffer for read
   '   count   - msg number that unmanaged buffer can preserve
   '   xferred - real msgs have read
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acCanRead(ByVal msgs() As IcanMsg, ByVal count As Integer, ByRef xferred As Integer) As Integer
      If count > MAX_RX_NUMBER Then
         count = MAX_RX_NUMBER
      End If

      Return acCanRead(hDevice, msgs, count, xferred, rxOvlap)
   End Function

   '*****************************************************************************
   'acCanWrite
   '   Write can msg
   'Arguments:
   '   msgs    - managed buffer for write
   '   count   - msg number for write
   '   xferred - real messages have written
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '*****************************************************************************  
   Public Function acCanWrite(ByVal msgs() As IcanMsg, ByVal count As Integer, ByRef xferred As Integer) As Integer
      If count > MAX_TX_NUMBER Then
         count = MAX_TX_NUMBER
      End If

      Return acCanWrite(hDevice, msgs, count, xferred, txOvlap)
   End Function


   '*****************************************************************************
   'acWaitEvent
   '   Wait can message or error of the CAN Controller.
   'Arguments:
   '   msgs    - managed buffer for read
   '   count   - msg number that unmanaged buffer can preserve
   '   xferred - real msgs have read
   '   errors  - return error code when the CAN Controller has error
   'Returns:
   '   =0 SUCCESS; or <0 failure 
   '****************************************************************************
   Public Function acWaitEvent(ByVal msgs() As IcanMsg, ByVal count As Integer, ByRef xferred As Integer, ByRef errors As Integer) As Integer
      Return acWaitEvent(hDevice, msgs, count, xferred, errors, evOvlap)
   End Function

   '----------------------------------------------------------------------------
   'DESCRIPTION: AdvCan API Declaration
   '----------------------------------------------------------------------------
   <DllImport("AdvCan.dll", CharSet:=CharSet.Unicode)> _
   Private Shared Function acCanOpenW(ByVal name As String, ByVal synchronization As Integer) As IntPtr
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acCanClose(ByVal hObject As IntPtr) As Integer
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acGetStatus(ByVal hObject As IntPtr, ByRef status As CanStatusPar_t) As Integer
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acClearCommError(ByVal hObject As IntPtr, ByRef errors As Integer) As Boolean
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acCanRead(ByVal hDevice As IntPtr, <Out()> ByVal msgs() As IcanMsg, ByVal count As Integer, ByRef xferred As Integer, <[In]()> ByRef ov As NativeOverlapped) As Integer
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acCanWrite(ByVal hDevice As IntPtr, <[In]()> ByVal msgs() As IcanMsg, ByVal count As Integer, ByRef xferred As Integer, <[In]()> ByRef ov As NativeOverlapped) As Integer
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acWaitEvent(ByVal hFile As Integer, <Out()> ByVal msgs() As IcanMsg, ByVal count As Integer, ByRef xferred As Integer, ByRef errors As Integer, <[In]()> ByRef ov As NativeOverlapped) As Integer
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acCanCommand(ByVal hObject As IntPtr, ByVal cmd As Integer, ByVal val1 As Integer, ByVal val2 As Integer) As Integer
   End Function

   <DllImport("AdvCan.dll")> _
   Private Shared Function acCanConfigure(ByVal hObject As IntPtr, ByVal target As Integer, ByVal val1 As Integer, ByVal val2 As Integer) As Integer
   End Function

End Class


Public Class Win32Events

   Sub New(ByVal ol As IntPtr)
      olPtr = ol
      evPtr = Marshal.AllocHGlobal(Marshal.SizeOf(GetType(Integer)))
      Marshal.WriteInt32(evPtr, 0)
   End Sub

   Protected Overrides Sub Finalize()
      Marshal.FreeHGlobal(evPtr)
   End Sub

   Public evPtr As IntPtr
   Public olPtr As IntPtr
End Class

Public Class Win32Ovrlap
   Sub New(ByVal evHandle As IntPtr)
      ol = New AdvCAN.OVERLAPPED()
      ol.offset = 0
      ol.offsetHigh = 0
      ol.hEvent = evHandle
      If (evHandle <> IntPtr.Zero) Then
         memPtr = Marshal.AllocHGlobal(Marshal.SizeOf(ol))
         Marshal.StructureToPtr(ol, memPtr, False)
      End If
   End Sub

   Protected Overrides Sub Finalize()
      If (memPtr <> IntPtr.Zero) Then
         Marshal.FreeHGlobal(memPtr)
      End If
   End Sub

   Public memPtr As IntPtr
   Public ol As AdvCan.OVERLAPPED
End Class
