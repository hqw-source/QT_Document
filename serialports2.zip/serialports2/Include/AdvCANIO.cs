// #############################################################################
// *****************************************************************************
//                  Copyright (c) 2011, Advantech Automation Corp.
//      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
//               INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
//
//    ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
//               ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
// *****************************************************************************

// #############################################################################
//
// File:    AdvCANIO.cs
// Created: 4/8/2009
// Revision:6/5/2009
// Version: 1.0
//          - Initial version
//          2.0
//          - Compatible with 64-bit and 32-bit system
//          2.1 (2011-5-19)
//          - Fix bug of  WaitCommEvent
// Description: Implements IO function about how to access CAN WDM&CE driver
//
// -----------------------------------------------------------------------------

using System;
using Microsoft.Win32.SafeHandles;
using System.Threading;
using System.Runtime.InteropServices;

public class AdvCANIO
{
   public const int SUCCESS = 0;                          //Status definition : success
   public const int OPERATION_ERROR = -1;                 //Status definition : device error or parameter error
   public const int TIME_OUT = -2;                        //Status definition : time out

   // Device handle
   private IntPtr hDevice;

   // Message send
   private uint MAX_TX_NUMBER;                            //Max number of message in unmanaged buffer for write
   private AutoResetEvent txEvent;
   private NativeOverlapped txOvlap;

   // Message receive
   private uint MAX_RX_NUMBER;                            //Max number of message in unmanaged buffer for read 
   private AutoResetEvent rxEvent;
   private NativeOverlapped rxOvlap;

   // Event overlap
   private NativeOverlapped evOvlap;

   public AdvCANIO()
   {
      hDevice = IntPtr.Zero;

      txEvent = new AutoResetEvent(false);
      txOvlap = new NativeOverlapped();
      txOvlap.EventHandle = txEvent.SafeWaitHandle.DangerousGetHandle();

      rxEvent = new AutoResetEvent(false);
      rxOvlap = new NativeOverlapped();
      rxOvlap.EventHandle = rxEvent.SafeWaitHandle.DangerousGetHandle();

      evOvlap = new NativeOverlapped();
      evOvlap.EventHandle = rxEvent.SafeWaitHandle.DangerousGetHandle();
   }

   ~AdvCANIO()
   {
      if (hDevice != IntPtr.Zero) {
         AdvCan.CloseHandle(hDevice);
         Thread.Sleep(100);

         hDevice = IntPtr.Zero;
      }
   }

   /*****************************************************************************
   *acCanOpen
   *   open can port by name 
   *Arguments:
   *   name                    - port name
   *   synchronization         - True, synchronization ; False, asynchronous
   *   MsgNumberOfReadBuffer   - message number of read intptr
   *   MsgNumberOfWriteBuffer  - message number of write intptr
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acCanOpen(string name, bool synchronization, uint MsgNumberOfReadBuffer, uint MsgNumberOfWriteBuffer)
   {
      hDevice = acCanOpenW(name, synchronization ? 1 : 0);
      if (hDevice.ToInt32() == -1) {
         hDevice = IntPtr.Zero;
         return OPERATION_ERROR;
      }

      MAX_RX_NUMBER = MsgNumberOfReadBuffer;
      MAX_TX_NUMBER = MsgNumberOfWriteBuffer;
      return SUCCESS;
   }

   /*****************************************************************************
   *acCanClose
   *   Close can port 
   *Arguments:
   *
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acCanClose()
   {
      if (hDevice != IntPtr.Zero) {
         acCanClose(hDevice);
         Thread.Sleep(100);

         hDevice = IntPtr.Zero;
      }
      
      return SUCCESS;
   }

   /*****************************************************************************
   *acEnterResetMode
   *   Enter reset mode.
   *Arguments:
   *   
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acEnterResetMode()
   {
      return acCanCommand(hDevice, AdvCan.CMD_STOP, 1, 1);
   }

   /*****************************************************************************
   *acEnterWorkMode
   *   Enter work mode 
   *Arguments:
   *   
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acEnterWorkMode()
   {
      return acCanCommand(hDevice, AdvCan.CMD_START, 0, 0);
   }

   /*****************************************************************************
   *acClearRxFifo
   *   Clear can port rx buffer by handle 
   *Arguments:
   *   
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acClearRxFifo()
   {
      return acCanCommand(hDevice, AdvCan.CMD_CLEARBUFFERS, 0, 0);
   }

   /*****************************************************************************
   *acSetBaud
   *   Set baud rate of the CAN Controller.The two modes of configuring
   *   baud rate are custom mode and standard mode.
   *   - Custom mode
   *       If Baud Rate value is user defined, driver will write the first 8
   *       bit of low 16 bit in BTR0 of SJA1000.
   *       The lower order 8 bit of low 16 bit will be written in BTR1 of SJA1000.
   *   - Standard mode
   *       Target value     BTR0      BTR1      Setting value 
   *         10K            0x31      0x1c      10 
   *         20K            0x18      0x1c      20 
   *         50K            0x09      0x1c      50 
   *        100K            0x04      0x1c      100 
   *        125K            0x03      0x1c      125 
   *        250K            0x01      0x1c      250 
   *        500K            0x00      0x1c      500 
   *        800K            0x00      0x16      800 
   *       1000K            0x00      0x14      1000 
   *Arguments:
   *   baud    - baud rate will be set
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acSetBaud(uint baud)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_TIMING, baud, 0);
   }

   /*****************************************************************************
   *acSetBaudRegister
   *   Configures baud rate by custom mode.
   *Arguments:
   *   btr0    - BTR0 register value.
   *   btr1    - BTR1 register value.
   *Returns:
   *    =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acSetBaudRegister(Byte btr0, Byte btr1)
   {
      return acSetBaud((uint)(btr0) * 256 + btr1);
   }

   /*****************************************************************************
   *acSetTimeOut
   *   Set Timeout for read and write
   *Arguments:
   *   readTimeOut  - ms
   *   writeTimeOut - ms
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acSetTimeOut(uint readTimeOut, uint writeTimeOut)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_TIMEOUT, writeTimeOut, readTimeOut);
   }

   /*****************************************************************************
   *acSetSelfReception
   *   Set Self Reception mode
   *Arguments:
   *   self - TRUE, open self reception; FALSE close self reception
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acSetSelfReception(bool self)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_SELF_RECEPTION, (uint)(self ? 1 : 0), 0);
   }

   /*****************************************************************************
   *acSetListenOnlyMode
   *   Set listen only mode
   *Arguments:
   *   listenOnly - TRUE, open only listen mode; FALSE, close only listen mode
   *Returns:
   *   =0 succeeded; or <0 Failed 
   *****************************************************************************/
   public int acSetListenOnlyMode(bool listenOnly)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_LISTEN_ONLY_MODE, (uint)(listenOnly ? 1 : 0), 0);
   }

   /*****************************************************************************
   *acSetAcceptanceFilterMode
   *   Set acceptance filter mode
   *Arguments:
   *   mode - PELICAN_SINGLE_FILTER, single filter mode; PELICAN_DUAL_FILTER, dule filter mode
   *Returns:
   *   =0 succeeded; or <0 Failed 
   *****************************************************************************/
   public int acSetAcceptanceFilterMode(uint mode)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_ACC_FILTER, mode, 0);
   }

   /*****************************************************************************
   *acSetAcceptanceFilterMask
   *   Set acceptance filter mask of the CAN Controller
   *Arguments:
   *   mask - accept mask code
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acSetAcceptanceFilterMask(uint mask)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_ACCM, mask, 0);
   }

   /*****************************************************************************
   *acSetAcceptanceFilterCode
   *   Set acceptance filter code of the CAN Controller
   *Arguments:
   *   code - acceptance code
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acSetAcceptanceFilterCode(uint code)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_ACCC, code, 0);
   }

   /*****************************************************************************
   *acSetAcceptanceFilter
   *   Set acceptance filter code and mask of the CAN Controller
   *Arguments:
   *   code    - acceptance code
   *   mask    - acceptance mask
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acSetAcceptanceFilter(uint mask, uint code)
   {
      return acCanConfigure(hDevice, AdvCan.CONF_ACC, mask, code);
   }

   /*****************************************************************************
   *acSetCommMask
   *   Execute SetCommMask.
   *Arguments:
   *   mask - event type
   *Returns:
   *   TRUE SUCCESS; or FALSE failure 
   *****************************************************************************/
   public bool acSetCommMask(uint mask)
   {
      return AdvCan.SetCommMask(hDevice, mask);
   }

   /*****************************************************************************
   *acGetCommMask
   *   Execute GetCommMask.
   *Arguments:
   *   mask - event type
   *Returns:
   *   TRUE SUCCESS; or FALSE failure 
   *****************************************************************************/
   public bool acGetCommMask(ref uint mask)
   {
      return AdvCan.GetCommMask(hDevice, ref mask);
   }

   /*****************************************************************************
   *acGetStatus
   *   Get the current status of the driver and the CAN Controller
   *Arguments:
   *   status  - status buffer
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acGetStatus(ref AdvCan.CanStatusPar_t status)
   {
      return acGetStatus(hDevice, ref status);
   }

   /*****************************************************************************
   *acClearCommError
   *   Execute ClearCommError of AdvCan.
   *Arguments:
   *   errors - error code if the CAN Controller occur error
   *Returns:
   *    TRUE SUCCESS; or FALSE failure 
   *****************************************************************************/
   public bool acClearCommError(ref uint errors)
   {
      return acClearCommError(hDevice, ref errors);
   }

   /*****************************************************************************
   *acCanRead
   *   Read can message
   *Arguments:
   *   msgs    - data buffer
   *   count   - msg number of data buffer size
   *   xferred - real MSGs have read
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acCanRead(AdvCan.IcanMsg[] msgs, uint count, ref uint xferred)
   {
      if (count > MAX_RX_NUMBER) {
         count = MAX_RX_NUMBER;
      }
      
      return acCanRead(hDevice, msgs, count, out xferred, ref rxOvlap);
   }

   /*****************************************************************************
   *acCanWrite
   *   Write can msg
   *Arguments:
   *   msgs    - data buffer
   *   count   - MSGs number
   *   xferred - real MSGs have written
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acCanWrite(AdvCan.IcanMsg[] msgs, uint count, ref uint xferred)
   {
      if (count > MAX_TX_NUMBER) {
         count = MAX_TX_NUMBER;
      }

      return acCanWrite(hDevice, msgs, count, out xferred, ref txOvlap);
   }

   /*****************************************************************************
   *acWaitEvent
   *   Wait can message or error of the CAN Controller.
   *Arguments:
   *   msgs    - buffer for read
   *   count   - MSGs number
   *   xferred - real MSGs have read
   *   errors  - return error code when the CAN Controller has error
   *Returns:
   *   =0 SUCCESS; or <0 failure 
   *****************************************************************************/
   public int acWaitEvent(AdvCan.IcanMsg[] msgs, uint count, ref uint xferred, ref uint errors)
   {
      return acWaitEvent(hDevice, msgs, count, out xferred, out errors, ref evOvlap);
   }

   //----------------------------------------------------------------------------
   //DESCRIPTION: AdvCan API Declaration
   //----------------------------------------------------------------------------
   [DllImport("AdvCan.dll", CharSet = CharSet.Unicode)]
   private static extern IntPtr acCanOpenW(string name, int synchronization);

   [DllImport("AdvCan.dll")]
   private static extern int acCanClose(IntPtr hDevice);

   [DllImport("AdvCan.dll")]
   private static extern int acGetStatus(IntPtr hDevice, ref AdvCan.CanStatusPar_t status);

   [DllImport("AdvCan.dll")]
   private static extern bool acClearCommError(IntPtr hDevice, ref uint errors);

   [DllImport("AdvCan.dll")]
   private static extern int acCanRead(IntPtr hDevice, [Out]AdvCan.IcanMsg[] msg, uint count, out uint xferred, [In]ref NativeOverlapped ov);

   [DllImport("AdvCan.dll")]
   private static extern int acCanWrite(IntPtr hDevice, [In]AdvCan.IcanMsg[] msg, uint count, out uint xferred, [In]ref NativeOverlapped ov);

   [DllImport("AdvCan.dll")]
   private static extern int acWaitEvent(IntPtr hDevice, [Out]AdvCan.IcanMsg[] msg, uint count, out uint xferred, out uint errors, [In]ref NativeOverlapped ov);

   [DllImport("AdvCan.dll")]
   private static extern int acCanCommand(IntPtr hDevice, int cmd, uint val1, uint val2);

   [DllImport("AdvCan.dll")]
   private static extern int acCanConfigure(IntPtr hDevice, int target, uint val1, uint val2);
}

internal class Win32Events
{
   // Methods
   internal Win32Events(IntPtr ol)
   {
      this.olPtr = ol;
      this.evPtr = Marshal.AllocHGlobal(sizeof(uint));
      Marshal.WriteInt32(this.evPtr, 0);
   }

   ~Win32Events()
   {
      Marshal.FreeHGlobal(this.evPtr);
   }

   public IntPtr evPtr;
   public IntPtr olPtr;
}

internal class Win32Ovrlap
{
   // Methods
   internal Win32Ovrlap(IntPtr evHandle)
   {
      this.ol = new AdvCan.OVERLAPPED();
      this.ol.offset = 0;
      this.ol.offsetHigh = 0;
      this.ol.hEvent = evHandle;
      if (evHandle != IntPtr.Zero)
      {
         this.memPtr = Marshal.AllocHGlobal(Marshal.SizeOf(this.ol));
         Marshal.StructureToPtr(this.ol, this.memPtr, false);
      }
   }

   ~Win32Ovrlap()
   {
      if (this.memPtr != IntPtr.Zero)
      {
         Marshal.FreeHGlobal(this.memPtr);
      }
   }

   public IntPtr memPtr;
   public AdvCan.OVERLAPPED ol;

}