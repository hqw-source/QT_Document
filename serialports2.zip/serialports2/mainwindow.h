#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QSerialPort>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void init();
private slots:
    void on_openPortBtn_released();

    void on_sendBtn_released();

    void onReadyRead();

    void on_openFlieBtn_released();

    void on_sendFlie_released();

    void on_clearRecbBtn_released();

    void on_savefileBtn_released();

    void on_sendClearBtn_released();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QSerialPort serialPort_;
};
#endif // MAINWINDOW_H
