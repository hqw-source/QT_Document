#include "mainwindow.h"
#include "./ui_mainwindow.h"

#include <QtSerialPort/QSerialPortInfo>
#include <QIODevice>
#include <QMessageBox>
#include <QFileDialog>
#include <QFile>
#include <QStandardPaths>
#include <QTimer>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    init();
    QTimer* Time1=new QTimer(this);
    Time1->start(1000);
    connect(Time1,&QTimer::timeout,[=]{
        ui->timeDisplayHour->display(QTime::currentTime().hour());
        ui->timeDisplayMin->display(QTime::currentTime().minute());
        ui->timeDisplaySec->display(QTime::currentTime().second());
        ui->sendEdit->setPlainText(QString::number(QTime::currentTime().hour(),10)
                                   +""+QString::number(QTime::currentTime().minute(),10)
                                   +""+QString::number(QTime::currentTime().second(),10));

    });

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::init()
{
    //获取所有的可用串口
   auto portsInfo = QSerialPortInfo::availablePorts();
    for (auto& info : portsInfo)
   {
       qInfo()<<info.description()<<info.portName()<<info.systemLocation();
        ui->portsCmb->addItem(info.portName() +":"+info.description(),info.portName());
    }
    //获取波特率
    qInfo()<<QSerialPortInfo::standardBaudRates();
    QList<qint32> baudRates = QSerialPortInfo::standardBaudRates();
    for(auto  br : baudRates)
    {
        ui->baudRateCmb->addItem(QString::number(br),br);
    }
    ui->baudRateCmb->setCurrentText("9600");
    //设置停止位
    ui->stopBitCmb->addItem("1",QSerialPort::OneStop);
    ui->stopBitCmb->addItem("2",QSerialPort::TwoStop);
    ui->stopBitCmb->addItem("1.5",QSerialPort::OneAndHalfStop);
    //设置数据位
    ui->dataRateCmb->addItem("5",QSerialPort::Data5);
    ui->dataRateCmb->addItem("6",QSerialPort::Data6);
    ui->dataRateCmb->addItem("7",QSerialPort::Data7);
    ui->dataRateCmb->addItem("8",QSerialPort::Data8);
    ui->dataRateCmb->setCurrentText("8");
    //设置校验位
    ui->parityCmb->addItem("NoParity",QSerialPort::NoParity);
    ui->parityCmb->addItem("OddParity",QSerialPort::OddParity);
    ui->parityCmb->addItem("EvenParity",QSerialPort::EvenParity);
    ui->parityCmb->addItem("SpaceParity",QSerialPort::SpaceParity);
    ui->parityCmb->addItem("MarkParity",QSerialPort::MarkParity);
    connect(&serialPort_,&QSerialPort::readyRead,this,&MainWindow::onReadyRead);
}

void MainWindow::on_openPortBtn_released()
{
    //串口是否打开
    if(serialPort_.isOpen())
    {
        serialPort_.close();
        ui->openPortBtn->setText("打开串口");
        return;
    }
    //获取串口
    auto portName= ui->portsCmb->currentData().toString();
    //获取波特率
    auto baudRate= ui->baudRateCmb->currentData().value<QSerialPort::BaudRate>();
    auto dataBits= ui->dataRateCmb->currentData().value<QSerialPort::DataBits>();
    auto parity=ui->parityCmb->currentData().value<QSerialPort::Parity>();
    auto stopBits=ui->stopBitCmb->currentData().value<QSerialPort::StopBits>();

    serialPort_.setPortName(portName);
    serialPort_.setBaudRate(baudRate);
    serialPort_.setDataBits(dataBits);
    serialPort_.setStopBits(stopBits);
    serialPort_.setParity(parity);

    if(!serialPort_.open(QIODevice::ReadWrite))
    {
        QMessageBox::warning(this,"warning",portName+"open falied:"+serialPort_.errorString());
        return;
    }
    else
    {
        ui->openPortBtn->setText("关闭串口");
    }
}

void MainWindow::on_sendBtn_released()
{

    auto dataStr = ui->sendEdit->toPlainText();

    serialPort_.write(dataStr.toLocal8Bit());

}
void MainWindow::onReadyRead()
{
    auto data = serialPort_.readAll();

    ui->recvEdit->setPlainText(QString::fromLocal8Bit(data));
    if(data=="a")
    {
         serialPort_.write("a");
    }

}
void MainWindow::on_openFlieBtn_released()
{
    auto filename= QFileDialog::getOpenFileName(this,"选择文件",QStandardPaths::writableLocation(QStandardPaths::DesktopLocation),
                                  "txt(*.txt);;all(*.*)");
    if(!filename.isEmpty())
    {
        ui->fileNameEdit->setPlainText(filename);
    }
}
void MainWindow::on_sendFlie_released()
{
    auto filename = ui->fileNameEdit->toPlainText();
    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this,"warning",filename+"open failed:"+file.errorString());
    }
    serialPort_.write(file.readAll());
}

//保存文件
void MainWindow::on_savefileBtn_released()
{
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString fileName = QString("C:/Users/hqwbook/Desktop/1.txt").arg(currentDateTime.toString("yyyyMMdd_hhmmss"));
    QFile file(fileName);
    if (file.open(QIODevice::WriteOnly))
    {
        file.write("123",4);
        file.close();
    }
}

void MainWindow::on_clearRecbBtn_released()
{
    ui->recvEdit->clear();
}

void MainWindow::on_sendClearBtn_released()
{
    ui->sendEdit->clear();
}


void MainWindow::on_pushButton_clicked()//校准时间
{

}

